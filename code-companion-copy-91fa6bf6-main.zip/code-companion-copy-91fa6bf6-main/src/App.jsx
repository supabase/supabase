import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Home from './pages/Home';
import AdminDashboard from './pages/AdminDashboard';
import TeamDashboard from './pages/TeamDashboard';
import ClientDashboard from './pages/ClientDashboard';
import CarRecommendation from './pages/CarRecommendation';
import CompareModels from './pages/CompareModels';
import VirtualTestDrive from './pages/VirtualTestDrive';
import IModelsExplorer from './pages/iModelsExplorer';
import SuperAdminDashboard from './pages/SuperAdminDashboard';
import ClientPortal from './pages/ClientPortal';
import ThreatsMonitoring from './pages/ThreatsMonitoring';
import InvestmentPortfolios from './pages/InvestmentPortfolios';
import Marketing from './pages/Marketing';
import Automation from './pages/Automation';
import Compliance from './pages/Compliance';
import Integrations from './pages/Integrations';
import AlertsDashboard from './pages/AlertsDashboard';
import ITwinApps from './pages/iTwinApps';
import Organizations from './pages/Organizations';
import DeploymentHistory from './pages/DeploymentHistory';
import HealthMonitor from './pages/HealthMonitor';
import Licenses from './pages/Licenses';
import EnvironmentDetail from './pages/EnvironmentDetail';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/team" element={<TeamDashboard />} />
      <Route path="/client" element={<ClientDashboard />} />
      <Route path="/recommendation" element={<CarRecommendation />} />
      <Route path="/compare-models" element={<CompareModels />} />
      <Route path="/virtual-test-drive" element={<VirtualTestDrive />} />
      <Route path="/imodels" element={<IModelsExplorer />} />
      <Route path="/superadmin" element={<SuperAdminDashboard />} />
      <Route path="/portal" element={<ClientPortal />} />
      <Route path="/threats" element={<ThreatsMonitoring />} />
      <Route path="/investments" element={<InvestmentPortfolios />} />
      <Route path="/marketing" element={<Marketing />} />
      <Route path="/automation" element={<Automation />} />
      <Route path="/compliance" element={<Compliance />} />
      <Route path="/integrations" element={<Integrations />} />
      <Route path="/alerts" element={<AlertsDashboard />} />
      <Route path="/itwin-apps" element={<ITwinApps />} />
      <Route path="/organizations" element={<Organizations />} />
      <Route path="/deployments" element={<DeploymentHistory />} />
      <Route path="/health" element={<HealthMonitor />} />
      <Route path="/licenses" element={<Licenses />} />
      <Route path="/environments" element={<EnvironmentDetail />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App