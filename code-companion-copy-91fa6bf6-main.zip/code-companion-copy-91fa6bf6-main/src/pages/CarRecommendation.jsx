import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles, ArrowLeft } from 'lucide-react';
import RecommendationResults from '@/components/RecommendationResults';

export default function CarRecommendation() {
  const navigate = useNavigate();
  const [step, setStep] = useState('preferences'); // preferences, loading, results
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState([]);
  const [analysis, setAnalysis] = useState('');

  const [formData, setFormData] = useState({
    budget_min: '',
    budget_max: '',
    intended_use: [],
    desired_features: '',
    family_size: '',
    lifestyle: ''
  });

  const useOptions = ['Family', 'Commute', 'Off-road', 'Luxury Travel', 'Performance', 'Weekend Getaway'];
  const lifestyleOptions = ['Urban', 'Suburban', 'Rural', 'Mixed'];

  const toggleUse = (use) => {
    setFormData(prev => ({
      ...prev,
      intended_use: prev.intended_use.includes(use)
        ? prev.intended_use.filter(u => u !== use)
        : [...prev.intended_use, use]
    }));
  };

  const handleGetRecommendations = async () => {
    if (!formData.budget_min || !formData.budget_max || formData.intended_use.length === 0) {
      alert('Please fill in budget and select at least one intended use');
      return;
    }

    setStep('loading');
    setLoading(true);

    try {
      const prompt = `Based on the following customer preferences, analyze and recommend the best Bentley models:

Budget: $${formData.budget_min}K - $${formData.budget_max}K
Intended Uses: ${formData.intended_use.join(', ')}
Desired Features: ${formData.desired_features || 'Not specified'}
Family Size: ${formData.family_size || 'Not specified'}
Lifestyle: ${formData.lifestyle || 'Not specified'}

Please provide:
1. Top 3 Bentley model recommendations that match these preferences
2. For each model, explain why it's a good fit
3. Key advantages and how they align with the customer's needs
4. Any considerations or alternatives

Format your response as a JSON object with the following structure:
{
  "recommendations": [
    {
      "model_name": "string",
      "reason": "string",
      "advantages": ["string"],
      "price_estimate": "string",
      "match_score": "percentage"
    }
  ],
  "overall_analysis": "string",
  "next_steps": ["string"]
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            recommendations: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  model_name: { type: 'string' },
                  reason: { type: 'string' },
                  advantages: { type: 'array', items: { type: 'string' } },
                  price_estimate: { type: 'string' },
                  match_score: { type: 'string' }
                }
              }
            },
            overall_analysis: { type: 'string' },
            next_steps: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      setRecommendations(result.recommendations || []);
      setAnalysis(result.overall_analysis || '');
      setStep('results');
    } catch (error) {
      console.error('Error getting recommendations:', error);
      alert('Failed to get recommendations. Please try again.');
      setStep('preferences');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Analyzing Your Preferences</h2>
          <p className="text-slate-400">Our AI is finding the perfect Bentley for you...</p>
        </div>
      </div>
    );
  }

  if (step === 'results') {
    return (
      <RecommendationResults
        recommendations={recommendations}
        analysis={analysis}
        formData={formData}
        onBack={() => setStep('preferences')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-blue-400 hover:text-blue-300 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-blue-500" />
            <h1 className="text-4xl font-bold text-white">AI Car Recommender</h1>
          </div>
          <p className="text-slate-400 text-lg">Tell us about your preferences, and our AI will suggest the perfect Bentley for you</p>
        </div>

        {/* Form */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 space-y-8">
          {/* Budget Section */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">What's Your Budget?</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-300 mb-2">Min Budget (in thousands)</label>
                <Input
                  type="number"
                  placeholder="e.g., 100"
                  value={formData.budget_min}
                  onChange={(e) => setFormData({ ...formData, budget_min: e.target.value })}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-300 mb-2">Max Budget (in thousands)</label>
                <Input
                  type="number"
                  placeholder="e.g., 300"
                  value={formData.budget_max}
                  onChange={(e) => setFormData({ ...formData, budget_max: e.target.value })}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
            </div>
          </div>

          {/* Intended Use */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">What Will You Use It For?</h3>
            <div className="grid md:grid-cols-3 gap-3">
              {useOptions.map((use) => (
                <button
                  key={use}
                  onClick={() => toggleUse(use)}
                  className={`px-4 py-2 rounded border transition-all ${
                    formData.intended_use.includes(use)
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-700 border-slate-600 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  {use}
                </button>
              ))}
            </div>
          </div>

          {/* Family Size */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Family Size</h3>
            <div className="grid md:grid-cols-4 gap-3">
              {['Solo', 'Couple', '3-4 People', '5+ People'].map((size) => (
                <button
                  key={size}
                  onClick={() => setFormData({ ...formData, family_size: size })}
                  className={`px-4 py-2 rounded border transition-all ${
                    formData.family_size === size
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-700 border-slate-600 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Lifestyle */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Lifestyle</h3>
            <div className="grid md:grid-cols-4 gap-3">
              {lifestyleOptions.map((lifestyle) => (
                <button
                  key={lifestyle}
                  onClick={() => setFormData({ ...formData, lifestyle })}
                  className={`px-4 py-2 rounded border transition-all ${
                    formData.lifestyle === lifestyle
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-700 border-slate-600 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  {lifestyle}
                </button>
              ))}
            </div>
          </div>

          {/* Desired Features */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Desired Features (Optional)</h3>
            <textarea
              placeholder="e.g., AWD, Advanced Safety Features, Premium Audio, Luxury Interior, Towing Capacity..."
              value={formData.desired_features}
              onChange={(e) => setFormData({ ...formData, desired_features: e.target.value })}
              className="w-full bg-slate-700 border border-slate-600 text-white rounded-lg p-3 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
              rows={4}
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleGetRecommendations}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Get AI Recommendations
          </Button>
        </div>
      </div>
    </div>
  );
}