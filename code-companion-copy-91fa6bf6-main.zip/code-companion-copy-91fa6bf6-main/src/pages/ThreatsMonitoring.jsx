import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const NAV = [
  { category: 'SECURITY', items: [
    { label: 'Threat Overview', path: '/threats', icon: '🛡' },
    { label: 'Live Alerts', path: '/threats', icon: '🚨' },
    { label: 'Incident Log', path: '/threats', icon: '📋' },
    { label: 'Vulnerability Scan', path: '/threats', icon: '🔍' },
  ]},
  { category: 'MONITORING', items: [
    { label: 'System Health', path: '/threats', icon: '💚' },
    { label: 'Compliance', path: '/compliance', icon: '⚖' },
  ]},
];

const THREATS = [
  { id: 'T-001', type: 'Brute Force', source: '185.220.101.45', target: 'Auth API', severity: 'critical', status: 'Blocked', time: '2m ago' },
  { id: 'T-002', type: 'SQL Injection', source: '103.45.67.89', target: 'Data API', severity: 'high', status: 'Investigating', time: '8m ago' },
  { id: 'T-003', type: 'DDoS Spike', source: 'Multiple IPs', target: 'Webhook Gateway', severity: 'high', status: 'Mitigated', time: '22m ago' },
  { id: 'T-004', type: 'Privilege Escalation', source: 'Internal', target: 'Admin Panel', severity: 'critical', status: 'Blocked', time: '45m ago' },
  { id: 'T-005', type: 'API Abuse', source: '52.44.21.11', target: 'iTwin API', severity: 'medium', status: 'Monitoring', time: '1h ago' },
  { id: 'T-006', type: 'Suspicious Login', source: '91.108.4.18', target: 'User Auth', severity: 'low', status: 'Resolved', time: '2h ago' },
];

const SEV_STYLE = {
  critical: 'bg-red-500/20 text-red-400 border border-red-500/30',
  high: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
  medium: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
  low: 'bg-slate-700 text-slate-400',
};

const HEALTH = [
  { label: 'Firewall', value: 'Active', ok: true },
  { label: 'WAF Rules', value: '2,847 Active', ok: true },
  { label: 'Rate Limiting', value: '60 req/min', ok: true },
  { label: 'SSL/TLS', value: 'TLS 1.3', ok: true },
  { label: 'Intrusion Detection', value: 'Running', ok: true },
  { label: 'SIEM Integration', value: 'Planned', ok: false },
];

export default function ThreatsMonitoring() {
  const { currentUser } = useAuth();
  const [severityFilter, setSeverityFilter] = useState('all');
  const [threats, setThreats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ type: 'Suspicious Login', source_ip: '', target: '', severity: 'medium', status: 'Investigating' });

  useEffect(() => {
    base44.entities.SecurityEvent.list('-created_date', 100).then(data => {
      setThreats(data);
      setLoading(false);
    });
    const unsub = base44.entities.SecurityEvent.subscribe(e => {
      if (e.type === 'create') setThreats(p => [e.data, ...p]);
      else if (e.type === 'update') setThreats(p => p.map(t => t.id === e.id ? e.data : t));
      else if (e.type === 'delete') setThreats(p => p.filter(t => t.id !== e.id));
    });
    return unsub;
  }, []);

  const createEvent = async () => {
    if (!form.type.trim()) return;
    await base44.entities.SecurityEvent.create({
      ...form,
      event_id: `T-${Date.now().toString().slice(-4)}`,
    });
    setForm({ type: 'Suspicious Login', source_ip: '', target: '', severity: 'medium', status: 'Investigating' });
    setShowCreate(false);
  };

  const updateStatus = async (threat, status) => {
    await base44.entities.SecurityEvent.update(threat.id, { status });
  };

  const filtered = threats.filter(t => severityFilter === 'all' || t.severity === severityFilter);

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Security" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">🛡 Threats & Security Events</h1>
            <p className="text-slate-400 text-sm mt-1">Entity-backed security event log — no simulated live data</p>
          </div>
          <div className="flex items-center gap-2">
            {threats.filter(t => t.severity === 'critical' && t.status !== 'Resolved').length > 0 && (
              <><span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-red-400 text-xs font-medium">{threats.filter(t => t.severity === 'critical' && t.status !== 'Resolved').length} Critical Active</span></>
            )}
            <button onClick={() => setShowCreate(true)}
              className="bg-red-600 hover:bg-red-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ Log Event</button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Total Events', value: threats.length, icon: '🚨', color: 'text-red-400' },
              { label: 'Blocked/Mitigated', value: threats.filter(t => ['Blocked','Mitigated'].includes(t.status)).length, icon: '🛡', color: 'text-green-400' },
              { label: 'Investigating', value: threats.filter(t => t.status === 'Investigating').length, icon: '🔍', color: 'text-yellow-400' },
              { label: 'Critical', value: threats.filter(t => t.severity === 'critical').length, icon: '⚠', color: 'text-orange-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Threat Log */}
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Security Event Log</h2>
                <div className="flex gap-1">
                  {['all', 'critical', 'high', 'medium', 'low'].map(s => (
                    <button key={s} onClick={() => setSeverityFilter(s)}
                      className={`text-xs px-2 py-0.5 rounded capitalize transition ${severityFilter === s ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-slate-500 uppercase border-b border-slate-800">
                      <th className="text-left py-2 pr-3">ID</th>
                      <th className="text-left py-2 pr-3">Type</th>
                      <th className="text-left py-2 pr-3">Source</th>
                      <th className="text-left py-2 pr-3">Severity</th>
                      <th className="text-left py-2 pr-3">Status</th>
                      <th className="text-left py-2">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading && <tr><td colSpan={6} className="text-center text-slate-500 py-8">Loading...</td></tr>}
                  {!loading && filtered.length === 0 && <tr><td colSpan={6} className="text-center text-slate-600 py-8">No events logged. Use "+ Log Event" to add security events.</td></tr>}
                  {filtered.map((t) => (
                    <tr key={t.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-2.5 pr-3 font-mono text-slate-500">{t.event_id || t.id?.slice(0,6)}</td>
                      <td className="py-2.5 pr-3 text-white font-medium">{t.type}</td>
                      <td className="py-2.5 pr-3 text-slate-400 font-mono">{t.source_ip || '—'}</td>
                      <td className="py-2.5 pr-3">
                        <span className={`px-2 py-0.5 rounded-full capitalize text-xs ${SEV_STYLE[t.severity]}`}>{t.severity}</span>
                      </td>
                      <td className="py-2.5 pr-3">
                        <select value={t.status} onChange={e => updateStatus(t, e.target.value)}
                          className="bg-slate-800 border border-slate-700 text-slate-300 text-xs rounded px-1 py-0.5">
                          {['Blocked','Investigating','Mitigated','Monitoring','Resolved'].map(s => <option key={s}>{s}</option>)}
                        </select>
                      </td>
                      <td className="py-2.5 text-slate-600">{new Date(t.created_date).toLocaleString()}</td>
                    </tr>
                  ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* System Health */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Security Stack</h2>
              <div className="space-y-3">
                {HEALTH.map((h, i) => (
                  <div key={i} className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${h.ok ? 'bg-green-500' : 'bg-slate-600'}`} />
                      <span className="text-slate-400 text-sm">{h.label}</span>
                    </div>
                    <span className={`text-xs ${h.ok ? 'text-green-400' : 'text-slate-500'}`}>{h.value}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-red-500/5 border border-red-500/20 rounded-lg">
                <div className="text-red-400 text-xs font-semibold mb-1">⚠ Recommendations</div>
                <ul className="text-slate-400 text-xs space-y-1">
                  <li>• Enable SIEM integration</li>
                  <li>• Configure geo-blocking rules</li>
                  <li>• Add MFA enforcement</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold">Log Security Event</h3>
              <button onClick={() => setShowCreate(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <input value={form.type} onChange={e => setForm(f => ({...f, type: e.target.value}))}
              placeholder="Event type *" className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-red-500" />
            <input value={form.source_ip} onChange={e => setForm(f => ({...f, source_ip: e.target.value}))}
              placeholder="Source IP" className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-red-500" />
            <input value={form.target} onChange={e => setForm(f => ({...f, target: e.target.value}))}
              placeholder="Target (e.g. Auth API)" className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-red-500" />
            <div className="flex gap-3">
              <select value={form.severity} onChange={e => setForm(f => ({...f, severity: e.target.value}))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-red-500">
                {['critical','high','medium','low','info'].map(s => <option key={s}>{s}</option>)}
              </select>
              <select value={form.status} onChange={e => setForm(f => ({...f, status: e.target.value}))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-red-500">
                {['Investigating','Blocked','Mitigated','Monitoring','Resolved'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowCreate(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={createEvent} disabled={!form.type.trim()}
                className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">Log Event</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}