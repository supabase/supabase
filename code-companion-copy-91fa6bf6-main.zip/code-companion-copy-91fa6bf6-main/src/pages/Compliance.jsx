import { useState } from 'react';
import Sidebar from '@/components/Sidebar';

const NAV = [
  { category: 'COMPLIANCE', items: [
    { label: 'Overview', path: '/compliance', icon: '⚖' },
    { label: 'Regulatory Frameworks', path: '/compliance', icon: '📋' },
    { label: 'Audit Logs', path: '/compliance', icon: '🔍' },
    { label: 'Data Privacy', path: '/compliance', icon: '🔒' },
    { label: 'Risk Register', path: '/compliance', icon: '⚠' },
  ]},
  { category: 'REPORTING', items: [
    { label: 'Evidence Library', path: '/compliance', icon: '📁' },
    { label: 'Certifications', path: '/compliance', icon: '🏅' },
  ]},
];

const FRAMEWORKS = [
  { name: 'SOC 2 Type II', score: 94, status: 'Certified', renewed: 'Jan 2027', controls: 84, passed: 79 },
  { name: 'ISO 27001', score: 88, status: 'Certified', renewed: 'Mar 2027', controls: 114, passed: 100 },
  { name: 'GDPR', score: 91, status: 'Compliant', renewed: '—', controls: 46, passed: 42 },
  { name: 'HIPAA', score: 72, status: 'In Review', renewed: '—', controls: 62, passed: 45 },
  { name: 'FedRAMP', score: 58, status: 'In Progress', renewed: '—', controls: 325, passed: 189 },
];

const RISKS = [
  { title: 'Outdated TLS on Staging', category: 'Technical', severity: 'high', owner: 'Ops Team', due: '2026-04-15' },
  { title: 'Missing DPA with Vendor X', category: 'Legal', severity: 'critical', owner: 'Legal', due: '2026-04-10' },
  { title: 'Incomplete Access Reviews', category: 'Access Control', severity: 'medium', owner: 'Security', due: '2026-04-30' },
  { title: 'Unencrypted Backup Files', category: 'Data', severity: 'high', owner: 'Infra', due: '2026-04-20' },
  { title: 'Training Overdue — 12 Users', category: 'People', severity: 'low', owner: 'HR', due: '2026-05-01' },
];

const SEV_STYLE = {
  critical: 'bg-red-500/20 text-red-400',
  high: 'bg-orange-500/20 text-orange-400',
  medium: 'bg-yellow-500/20 text-yellow-400',
  low: 'bg-slate-700 text-slate-400',
};

const STATUS_STYLE = {
  Certified: 'bg-green-500/10 text-green-400',
  Compliant: 'bg-teal-500/10 text-teal-400',
  'In Review': 'bg-yellow-500/10 text-yellow-400',
  'In Progress': 'bg-blue-500/10 text-blue-400',
};

export default function Compliance() {
  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Compliance" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">⚖ Compliance & Regulatory Review</h1>
          <p className="text-slate-400 text-sm mt-1">Regulatory frameworks, risk register, audit trails, and certifications</p>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Overall Score', value: '84%', icon: '⭐', color: 'text-green-400' },
              { label: 'Frameworks', value: '5', icon: '📋', color: 'text-blue-400' },
              { label: 'Open Risks', value: '5', icon: '⚠', color: 'text-orange-400' },
              { label: 'Certifications', value: '2', icon: '🏅', color: 'text-teal-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Frameworks */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Regulatory Frameworks</h2>
            <div className="space-y-4">
              {FRAMEWORKS.map((f, i) => (
                <div key={i} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-white font-semibold">{f.name}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_STYLE[f.status]}`}>{f.status}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span>{f.passed}/{f.controls} controls</span>
                      {f.renewed !== '—' && <span>Renews {f.renewed}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-slate-700 rounded-full h-2">
                      <div className={`h-2 rounded-full ${f.score >= 90 ? 'bg-green-500' : f.score >= 75 ? 'bg-blue-500' : 'bg-orange-500'}`}
                        style={{ width: `${f.score}%` }} />
                    </div>
                    <span className="text-xs text-white w-10 text-right">{f.score}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Risk Register */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">⚠ Risk Register</h2>
              <button className="bg-orange-600 hover:bg-orange-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ Log Risk</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Risk</th>
                    <th className="text-left py-2 pr-4">Category</th>
                    <th className="text-left py-2 pr-4">Severity</th>
                    <th className="text-left py-2 pr-4">Owner</th>
                    <th className="text-left py-2">Due</th>
                  </tr>
                </thead>
                <tbody>
                  {RISKS.map((r, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white text-xs">{r.title}</td>
                      <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-400 text-xs px-2 py-0.5 rounded">{r.category}</span></td>
                      <td className="py-3 pr-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${SEV_STYLE[r.severity]}`}>{r.severity}</span>
                      </td>
                      <td className="py-3 pr-4 text-slate-400 text-xs">{r.owner}</td>
                      <td className="py-3 text-slate-500 text-xs font-mono">{r.due}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}