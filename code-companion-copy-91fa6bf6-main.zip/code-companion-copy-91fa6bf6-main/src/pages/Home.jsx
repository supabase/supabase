import { Link } from 'react-router-dom';
import { Shield, Users, Zap, BarChart2, Bell, Map, GitBranch, Settings, AlertTriangle, Layers } from 'lucide-react';

const MODULES = [
  { label: 'Admin Control', desc: 'Platform management & system config', icon: Shield, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20', path: '/admin' },
  { label: 'Team Operations', desc: 'Monitor projects & collaborate', icon: Users, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20', path: '/team' },
  { label: 'iModel Explorer', desc: 'Visualize 3D digital infrastructure', icon: GitBranch, color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/20', path: '/imodels' },
  { label: 'Client Portal', desc: 'Deliverables, billing & project status', icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20', path: '/portal' },
  { label: 'Threats & Security', desc: 'Real-time security monitoring', icon: Bell, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20', path: '/threats' },
  { label: 'Investments', desc: 'Portfolio tracking & analytics', icon: BarChart2, color: 'text-teal-400', bg: 'bg-teal-500/10 border-teal-500/20', path: '/investments' },
  { label: 'Marketing Hub', desc: 'Campaigns, traffic & growth', icon: Map, color: 'text-pink-400', bg: 'bg-pink-500/10 border-pink-500/20', path: '/marketing' },
  { label: 'Automation', desc: 'Workflows, triggers & schedules', icon: Settings, color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/20', path: '/automation' },
  { label: 'Alerts Center', desc: 'Incident tracking & notifications', icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20', path: '/alerts' },
  { label: 'iTwin App Manager', desc: 'Create, import & deploy iTwin apps', icon: Layers, color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/20', path: '/itwin-apps' },
];

const STATS = [
  { label: 'Active iModels', value: '6' },
  { label: 'System Uptime', value: '99.9%' },
  { label: 'Team Members', value: '38' },
  { label: 'Events Today', value: '1.2K' },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white text-sm">B</div>
          <div>
            <div className="text-white text-sm font-bold leading-tight">Bentley Ops Center</div>
            <div className="text-slate-500 text-[10px] leading-tight">iTwin Operations Platform</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs text-green-400">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            All Systems Operational
          </span>
        </div>
      </header>

      {/* Hero */}
      <section className="px-4 sm:px-6 pt-10 pb-8 text-center max-w-2xl mx-auto w-full">
        <div className="inline-flex items-center gap-2 bg-blue-600/10 border border-blue-500/20 text-blue-400 text-xs px-3 py-1 rounded-full mb-5">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
          Enterprise Platform · Live
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-white leading-tight mb-3">
          Digital Infrastructure<br />Command Center
        </h1>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed mb-6">
          Unified operations, monitoring, and project management for Bentley iTwin digital infrastructure. Designed for web and mobile.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/team" className="bg-blue-600 hover:bg-blue-700 text-white text-sm px-5 py-2.5 rounded-xl font-medium transition text-center">
            Open Operations →
          </Link>
          <Link to="/imodels" className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm px-5 py-2.5 rounded-xl font-medium transition text-center">
            Explore iModels
          </Link>
        </div>
      </section>

      {/* Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-4 sm:px-6 max-w-3xl mx-auto w-full pb-8">
        {STATS.map(s => (
          <div key={s.label} className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
            <div className="text-xl font-bold text-white">{s.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Module Grid */}
      <section className="flex-1 px-4 sm:px-6 pb-10 max-w-3xl mx-auto w-full">
        <div className="text-xs text-slate-600 uppercase tracking-widest font-semibold mb-4">Platform Modules</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {MODULES.map(m => {
            const Icon = m.icon;
            return (
              <Link key={m.label} to={m.path}
                className={`flex items-center gap-4 border rounded-2xl p-4 hover:brightness-110 transition ${m.bg}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-900/60 shrink-0">
                  <Icon className={`w-5 h-5 ${m.color}`} />
                </div>
                <div>
                  <div className="text-white text-sm font-semibold">{m.label}</div>
                  <div className="text-slate-400 text-xs mt-0.5">{m.desc}</div>
                </div>
                <span className="ml-auto text-slate-600 text-lg">›</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 px-6 py-4 text-center text-xs text-slate-600">
        © 2026 Bentley Ops Center · iTwin Operations Platform
      </footer>
    </div>
  );
}