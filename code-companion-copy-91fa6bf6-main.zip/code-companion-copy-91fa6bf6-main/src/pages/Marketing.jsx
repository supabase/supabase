import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import Sidebar from '@/components/Sidebar';
import { useState } from 'react';

const NAV = [
  { category: 'MARKETING', items: [
    { label: 'Overview', path: '/marketing', icon: '📣' },
    { label: 'Campaigns', path: '/marketing', icon: '🎯' },
    { label: 'Leads', path: '/marketing', icon: '👤' },
    { label: 'Email Automation', path: '/marketing', icon: '📧' },
    { label: 'SEO & Content', path: '/marketing', icon: '🔍' },
  ]},
  { category: 'ANALYTICS', items: [
    { label: 'Attribution', path: '/marketing', icon: '📊' },
    { label: 'Audiences', path: '/marketing', icon: '👥' },
  ]},
];

const CAMPAIGNS = [
  { name: 'Enterprise Q2 Outreach', channel: 'Email', leads: 284, conv: '12.4%', spend: '$4,200', status: 'Active' },
  { name: 'iTwin Platform Launch', channel: 'LinkedIn', leads: 591, conv: '8.7%', spend: '$9,800', status: 'Active' },
  { name: 'Smart City Webinar Series', channel: 'Webinar', leads: 142, conv: '22.1%', spend: '$1,400', status: 'Completed' },
  { name: 'Infrastructure Summit', channel: 'Event', leads: 89, conv: '34.8%', spend: '$12,000', status: 'Completed' },
  { name: 'Developer Community Q3', channel: 'Content', leads: 467, conv: '5.2%', spend: '$2,100', status: 'Draft' },
];

const TRAFFIC = [
  { m: 'Oct', v: 12400 }, { m: 'Nov', v: 14200 }, { m: 'Dec', v: 10800 },
  { m: 'Jan', v: 16900 }, { m: 'Feb', v: 18200 }, { m: 'Mar', v: 22100 }, { m: 'Apr', v: 24400 },
];

const CHANNELS = [
  { name: 'Organic Search', pct: 38 }, { name: 'LinkedIn', pct: 24 },
  { name: 'Email', pct: 18 }, { name: 'Referral', pct: 12 }, { name: 'Direct', pct: 8 },
];

const STATUS_STYLE = {
  Active: 'bg-green-500/10 text-green-400',
  Completed: 'bg-slate-700 text-slate-400',
  Draft: 'bg-yellow-500/10 text-yellow-400',
};

export default function Marketing() {
  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Marketing" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">📣 Marketing Hub</h1>
          <p className="text-slate-400 text-sm mt-1">Campaign management, lead tracking, and growth analytics</p>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Monthly Visitors', value: '24.4K', change: '+18% MoM', icon: '🌐', color: 'text-blue-400' },
              { label: 'Total Leads', value: '1,573', change: '+31% MoM', icon: '👤', color: 'text-purple-400' },
              { label: 'Conversion Rate', value: '14.2%', change: '+2.1pp', icon: '🎯', color: 'text-green-400' },
              { label: 'CAC', value: '$287', change: '-12% vs Q1', icon: '💰', color: 'text-teal-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">{k.icon}</span>
                  <span className="text-xs text-slate-500">{k.label}</span>
                </div>
                <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                <div className="text-xs text-green-500 mt-0.5">{k.change}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Monthly Web Traffic</h2>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={TRAFFIC}>
                  <defs>
                    <linearGradient id="mktGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="m" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }} itemStyle={{ color: '#c084fc' }} />
                  <Area type="monotone" dataKey="v" stroke="#a855f7" fill="url(#mktGrad)" strokeWidth={2} name="Visitors" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Traffic Sources</h2>
              <div className="space-y-3">
                {CHANNELS.map(c => (
                  <div key={c.name}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">{c.name}</span>
                      <span className="text-white">{c.pct}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${c.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Campaigns */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">Active Campaigns</h2>
              <button className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ New Campaign</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Campaign</th>
                    <th className="text-left py-2 pr-4">Channel</th>
                    <th className="text-left py-2 pr-4">Leads</th>
                    <th className="text-left py-2 pr-4">Conv.</th>
                    <th className="text-left py-2 pr-4">Spend</th>
                    <th className="text-left py-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {CAMPAIGNS.map((c, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white text-xs font-medium">{c.name}</td>
                      <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-400 text-xs px-2 py-0.5 rounded">{c.channel}</span></td>
                      <td className="py-3 pr-4 text-slate-300 text-xs">{c.leads}</td>
                      <td className="py-3 pr-4 text-green-400 text-xs">{c.conv}</td>
                      <td className="py-3 pr-4 text-slate-400 text-xs font-mono">{c.spend}</td>
                      <td className="py-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_STYLE[c.status]}`}>{c.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}