import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Loader2, Sparkles } from 'lucide-react';

export default function CompareModels() {
  const navigate = useNavigate();
  const location = useLocation();
  const { recommendations = [] } = location.state || {};
  
  const [selectedModels, setSelectedModels] = useState([]);
  const [comparison, setComparison] = useState(null);
  const [loading, setLoading] = useState(false);

  const toggleModel = (modelName) => {
    if (selectedModels.includes(modelName)) {
      setSelectedModels(selectedModels.filter(m => m !== modelName));
    } else if (selectedModels.length < 3) {
      setSelectedModels([...selectedModels, modelName]);
    }
  };

  const handleGenerateComparison = async () => {
    if (selectedModels.length === 0) {
      alert('Please select at least one model to compare');
      return;
    }

    setLoading(true);
    const modelsList = selectedModels.join(', ');

    try {
      const prompt = `Create a detailed comparison table for these Bentley models: ${modelsList}

For each model, provide comprehensive information organized by these categories:
1. Pricing & Dimensions
2. Engine & Performance
3. Interior Features & Luxury
4. Driving Experience
5. Safety & Technology
6. Best For (use case recommendations)
7. Key Differentiators

Format as JSON with structure:
{
  "models": [
    {
      "name": "string",
      "specs": {
        "pricing": "string",
        "dimensions": "string",
        "engine": "string",
        "horsepower": "string",
        "0_to_60": "string",
        "top_speed": "string"
      },
      "features": {
        "interior_highlights": ["string"],
        "luxury_features": ["string"],
        "technology": ["string"],
        "safety_features": ["string"]
      },
      "driving_experience": "string",
      "best_for": ["string"],
      "key_differentiators": ["string"],
      "price_range": "string"
    }
  ],
  "overall_comparison_summary": "string",
  "recommendations_by_priority": {
    "best_luxury": "string",
    "best_performance": "string",
    "best_value": "string"
  }
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            models: { type: 'array' },
            overall_comparison_summary: { type: 'string' },
            recommendations_by_priority: { type: 'object' }
          }
        }
      });

      setComparison(result);
    } catch (error) {
      console.error('Error generating comparison:', error);
      alert('Failed to generate comparison. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Generating Comparison</h2>
          <p className="text-slate-400">Analyzing the selected models...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-blue-400 hover:text-blue-300 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-4xl font-bold text-white mb-3 flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-blue-500" />
            Compare Bentley Models
          </h1>
          <p className="text-slate-400">Select up to 3 models to see a detailed side-by-side comparison</p>
        </div>

        {!comparison ? (
          <>
            {/* Model Selection */}
            <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-8">
              <h2 className="text-xl font-semibold text-white mb-6">Available Models</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                {recommendations.map((rec) => (
                  <button
                    key={rec.model_name}
                    onClick={() => toggleModel(rec.model_name)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedModels.includes(rec.model_name)
                        ? 'bg-blue-600 border-blue-500 text-white'
                        : 'bg-slate-700 border-slate-600 text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    <div className="font-semibold">{rec.model_name}</div>
                    <div className="text-sm">{rec.price_estimate}</div>
                    <div className="text-xs mt-2 opacity-75">{rec.match_score} match</div>
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="text-slate-400">
                  {selectedModels.length} of 3 models selected
                </div>
                <Button
                  onClick={handleGenerateComparison}
                  disabled={selectedModels.length === 0}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Comparison
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Comparison Results */}
            <div className="space-y-8">
              {/* Summary */}
              <div className="bg-blue-600/20 border border-blue-500/50 rounded-lg p-6">
                <h2 className="text-lg font-semibold text-white mb-3">Comparison Summary</h2>
                <p className="text-slate-300">{comparison.overall_comparison_summary}</p>
              </div>

              {/* Model Details */}
              {comparison.models?.map((model, idx) => (
                <div key={idx} className="bg-slate-800 border border-slate-700 rounded-lg p-8">
                  <h2 className="text-2xl font-bold text-white mb-6">{model.name}</h2>

                  {/* Specs Grid */}
                  <div className="mb-8">
                    <h3 className="text-lg font-semibold text-white mb-4">Specifications</h3>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {Object.entries(model.specs || {}).map(([key, value]) => (
                        <div key={key} className="bg-slate-700/50 rounded p-4">
                          <div className="text-xs text-slate-400 uppercase tracking-wide mb-1">
                            {key.replace(/_/g, ' ')}
                          </div>
                          <div className="text-white font-semibold">{value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Features */}
                  {model.features && (
                    <div className="mb-8">
                      <h3 className="text-lg font-semibold text-white mb-4">Features & Technology</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        {Object.entries(model.features).map(([category, items]) => (
                          <div key={category}>
                            <h4 className="text-sm font-semibold text-slate-300 uppercase mb-3">{category.replace(/_/g, ' ')}</h4>
                            <ul className="space-y-2">
                              {(Array.isArray(items) ? items : [items]).map((item, i) => (
                                <li key={i} className="text-slate-400 text-sm flex items-start gap-2">
                                  <span className="text-blue-400 mt-1">•</span>
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Driving Experience */}
                  {model.driving_experience && (
                    <div className="mb-8">
                      <h3 className="text-lg font-semibold text-white mb-3">Driving Experience</h3>
                      <p className="text-slate-300">{model.driving_experience}</p>
                    </div>
                  )}

                  {/* Best For */}
                  {model.best_for && (
                    <div className="mb-8">
                      <h3 className="text-lg font-semibold text-white mb-3">Best For</h3>
                      <div className="flex flex-wrap gap-2">
                        {model.best_for.map((use, i) => (
                          <span key={i} className="bg-blue-600/30 border border-blue-500/50 text-blue-300 px-3 py-1 rounded-full text-sm">
                            {use}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Key Differentiators */}
                  {model.key_differentiators && (
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-3">Key Differentiators</h3>
                      <ul className="space-y-2">
                        {model.key_differentiators.map((diff, i) => (
                          <li key={i} className="text-slate-400 flex items-start gap-2">
                            <span className="text-green-400 mt-1">✓</span>
                            <span>{diff}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}

              {/* Recommendations by Priority */}
              {comparison.recommendations_by_priority && (
                <div className="bg-purple-600/20 border border-purple-500/50 rounded-lg p-6">
                  <h2 className="text-lg font-semibold text-white mb-4">Recommendations by Priority</h2>
                  <div className="space-y-3">
                    {Object.entries(comparison.recommendations_by_priority).map(([priority, model]) => (
                      <div key={priority} className="flex items-center justify-between">
                        <span className="text-slate-300 capitalize">{priority.replace(/_/g, ' ')}</span>
                        <span className="font-semibold text-white">{model}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={() => setComparison(null)}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Select Different Models
                </Button>
                <Button
                  onClick={() => selectedModels.length > 0 && navigate('/virtual-test-drive', { state: { modelName: selectedModels[0] } })}
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  Virtual Test Drive
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}