import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import { Rocket, CheckCircle, XCircle, Clock, RotateCcw, Filter } from 'lucide-react';

const NAV = [
  { category: 'HIERARCHY', items: [
    { label: 'Organizations', path: '/organizations', icon: '🏢' },
    { label: 'Projects', path: '/projects', icon: '📁' },
    { label: 'Environments', path: '/environments', icon: '🌍' },
    { label: 'Deployments', path: '/deployments', icon: '🚀' },
  ]},
  { category: 'APPS', items: [
    { label: 'iTwin Apps', path: '/itwin-apps', icon: '⬡' },
    { label: 'Admin', path: '/admin', icon: '⚙' },
  ]},
];

const STATUS_STYLE = {
  queued: 'bg-slate-700 text-slate-400',
  building: 'bg-blue-500/10 text-blue-400 animate-pulse',
  deploying: 'bg-yellow-500/10 text-yellow-400 animate-pulse',
  deployed: 'bg-green-500/10 text-green-400',
  failed: 'bg-red-500/10 text-red-400',
  rolled_back: 'bg-orange-500/10 text-orange-400',
  cancelled: 'bg-slate-700 text-slate-500',
};

const STATUS_ICON = {
  deployed: CheckCircle, failed: XCircle, rolled_back: RotateCcw,
  building: Clock, deploying: Clock, queued: Clock, cancelled: XCircle,
};

const ENV_STYLE = {
  Production: 'bg-purple-500/10 text-purple-400',
  Staging: 'bg-yellow-500/10 text-yellow-400',
  Development: 'bg-slate-700 text-slate-400',
  preview: 'bg-teal-500/10 text-teal-400',
};

const STATUSES = ['All', 'deployed', 'building', 'deploying', 'failed', 'rolled_back', 'queued'];

export default function DeploymentHistory() {
  const { currentUser } = useAuth();
  const [deployments, setDeployments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    base44.entities.Deployment.list('-created_date', 200).then(data => {
      setDeployments(data);
      setLoading(false);
    });
    const unsub = base44.entities.Deployment.subscribe(event => {
      if (event.type === 'create') setDeployments(p => [event.data, ...p]);
      else if (event.type === 'update') setDeployments(p => p.map(d => d.id === event.id ? event.data : d));
      else if (event.type === 'delete') setDeployments(p => p.filter(d => d.id !== event.id));
    });
    return unsub;
  }, []);

  const triggerRollback = async (dep) => {
    await base44.entities.Deployment.create({
      app_name: dep.app_name,
      app_id: dep.app_id,
      environment_id: dep.environment_id,
      environment_name: dep.environment_name,
      environment_type: dep.environment_type,
      project_id: dep.project_id,
      organization_id: dep.organization_id,
      version: dep.version,
      status: 'queued',
      triggered_by: currentUser?.email,
      trigger_source: 'rollback',
      rollback_of: dep.id,
      started_at: new Date().toISOString(),
    });
  };

  const filtered = deployments.filter(d => statusFilter === 'All' || d.status === statusFilter);

  const counts = {
    total: deployments.length,
    deployed: deployments.filter(d => d.status === 'deployed').length,
    failed: deployments.filter(d => d.status === 'failed').length,
    active: deployments.filter(d => ['building', 'deploying', 'queued'].includes(d.status)).length,
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Developer" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Rocket className="w-5 h-5 text-green-400" /> Deployment History
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">All deployment events across environments — real-time</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-6 py-4 border-b border-slate-800">
          {[
            { label: 'Total', value: counts.total, color: 'text-white' },
            { label: 'Deployed', value: counts.deployed, color: 'text-green-400' },
            { label: 'In Progress', value: counts.active, color: 'text-blue-400' },
            { label: 'Failed', value: counts.failed, color: 'text-red-400' },
          ].map(k => (
            <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>

        <div className="px-6 py-3 border-b border-slate-800 flex items-center gap-2 flex-wrap">
          <Filter className="w-3.5 h-3.5 text-slate-500" />
          {STATUSES.map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`text-xs px-2 py-0.5 rounded-full transition capitalize ${statusFilter === s ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
              {s}
            </button>
          ))}
        </div>

        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 overflow-y-auto divide-y divide-slate-800">
            {loading && <div className="text-center text-slate-500 py-12">Loading deployments...</div>}
            {!loading && filtered.length === 0 && (
              <div className="text-center text-slate-600 py-16">
                <Rocket className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <div className="text-sm">No deployments yet.</div>
              </div>
            )}
            {filtered.map(dep => {
              const Icon = STATUS_ICON[dep.status] || Clock;
              return (
                <button key={dep.id} onClick={() => setSelected(dep)}
                  className={`w-full text-left px-6 py-4 hover:bg-slate-800/40 transition ${selected?.id === dep.id ? 'bg-slate-800/60 border-l-2 border-l-blue-500' : ''}`}>
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 shrink-0 ${dep.status === 'deployed' ? 'text-green-400' : dep.status === 'failed' ? 'text-red-400' : 'text-blue-400'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-white text-sm font-medium">{dep.app_name}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded ${STATUS_STYLE[dep.status]}`}>{dep.status}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded-full ${ENV_STYLE[dep.environment_type] || 'bg-slate-700 text-slate-400'}`}>{dep.environment_name || dep.environment_type}</span>
                        {dep.version && <span className="text-xs text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded">{dep.version}</span>}
                      </div>
                      <div className="text-slate-500 text-xs mt-0.5">
                        {dep.trigger_source} · by {dep.triggered_by} · {new Date(dep.created_date).toLocaleString()}
                        {dep.commit_message && <span> · {dep.commit_message.slice(0, 40)}</span>}
                      </div>
                    </div>
                    {dep.build_duration_ms && (
                      <span className="text-slate-600 text-xs shrink-0">{(dep.build_duration_ms / 1000).toFixed(1)}s</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {selected && (
            <div className="w-80 shrink-0 border-l border-slate-800 bg-slate-900 flex flex-col overflow-y-auto">
              <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <h3 className="text-white text-sm font-semibold">Deployment Detail</h3>
                <button onClick={() => setSelected(null)} className="text-slate-500 hover:text-white text-xs">✕</button>
              </div>
              <div className="p-4 space-y-4 text-xs">
                <div>
                  <div className="text-slate-500 mb-1 uppercase tracking-wide">App</div>
                  <div className="text-white font-semibold">{selected.app_name}</div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    ['Status', selected.status],
                    ['Version', selected.version || '—'],
                    ['Environment', selected.environment_name || '—'],
                    ['Trigger', selected.trigger_source],
                    ['By', selected.triggered_by],
                    ['Commit', selected.commit_sha?.slice(0, 7) || '—'],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-slate-800 rounded-lg p-2">
                      <div className="text-slate-500 mb-0.5">{k}</div>
                      <div className="text-white">{v}</div>
                    </div>
                  ))}
                </div>
                {selected.commit_message && (
                  <div>
                    <div className="text-slate-500 mb-1 uppercase tracking-wide">Commit</div>
                    <div className="text-slate-300">{selected.commit_message}</div>
                  </div>
                )}
                {selected.error_message && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                    <div className="text-red-400 text-xs">{selected.error_message}</div>
                  </div>
                )}
                {selected.rollback_of && (
                  <div className="text-slate-500 text-xs">↩ Rollback of: {selected.rollback_of}</div>
                )}
                <div className="flex flex-col gap-2 pt-2">
                  {selected.logs_url && (
                    <a href={selected.logs_url} target="_blank" rel="noreferrer"
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs py-2 rounded-lg text-center transition">
                      View Logs ↗
                    </a>
                  )}
                  <button onClick={() => { triggerRollback(selected); setSelected(null); }}
                    className="bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 text-xs py-2 rounded-lg transition flex items-center justify-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5" /> Rollback to this version
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}