import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import Sidebar from '@/components/Sidebar';

const NAV = [
  { category: 'INVESTMENTS', items: [
    { label: 'Portfolio Overview', path: '/investments', icon: '💼' },
    { label: 'Assets', path: '/investments', icon: '📈' },
    { label: 'Transactions', path: '/investments', icon: '💸' },
    { label: 'Risk Analysis', path: '/investments', icon: '⚡' },
  ]},
  { category: 'REPORTS', items: [
    { label: 'Performance', path: '/investments', icon: '📊' },
    { label: 'Compliance', path: '/compliance', icon: '⚖' },
  ]},
];

const ASSETS = [
  { name: 'Infrastructure Fund A', type: 'Real Asset', value: '$4.2M', change: '+8.4%', alloc: 32, positive: true },
  { name: 'Digital Twin Ventures', type: 'Tech Equity', value: '$2.8M', change: '+12.1%', alloc: 21, positive: true },
  { name: 'Smart City Bonds', type: 'Fixed Income', value: '$1.9M', change: '+3.2%', alloc: 14, positive: true },
  { name: 'Renewable Energy ETF', type: 'ESG Fund', value: '$2.1M', change: '-1.8%', alloc: 16, positive: false },
  { name: 'Global REIT Index', type: 'Real Estate', value: '$1.3M', change: '+5.7%', alloc: 10, positive: true },
  { name: 'Cash & Equivalents', type: 'Liquid', value: '$0.9M', change: '+0.1%', alloc: 7, positive: true },
];

const TREND = [
  { m: 'Oct', v: 11.2 }, { m: 'Nov', v: 11.8 }, { m: 'Dec', v: 12.4 },
  { m: 'Jan', v: 12.1 }, { m: 'Feb', v: 13.1 }, { m: 'Mar', v: 13.2 }, { m: 'Apr', v: 13.2 },
];

const PERF = [
  { m: 'Q1', return: 4.2 }, { m: 'Q2', return: 6.1 }, { m: 'Q3', return: 3.8 }, { m: 'Q4', return: 8.4 },
];

export default function InvestmentPortfolios() {
  const [view, setView] = useState('overview');

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Finance" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">💼 Investment Portfolios</h1>
          <p className="text-slate-400 text-sm mt-1">Asset management, performance tracking, and risk analysis</p>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Total AUM', value: '$13.2M', change: '+8.4%', icon: '💼', color: 'text-green-400' },
              { label: 'YTD Return', value: '+18.7%', change: 'vs 12.1% bench', icon: '📈', color: 'text-green-400' },
              { label: 'Risk Score', value: 'Moderate', change: '42/100', icon: '⚡', color: 'text-yellow-400' },
              { label: 'Active Assets', value: '6', change: '2 asset types', icon: '📁', color: 'text-blue-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">{k.icon}</span>
                  <span className="text-xs text-slate-500">{k.label}</span>
                </div>
                <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                <div className="text-xs text-slate-600 mt-0.5">{k.change}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Portfolio Trend */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Portfolio Value Trend (M)</h2>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={TREND}>
                  <defs>
                    <linearGradient id="portGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="m" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }} itemStyle={{ color: '#4ade80' }} />
                  <Area type="monotone" dataKey="v" stroke="#22c55e" fill="url(#portGrad)" strokeWidth={2} name="Value ($M)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Quarterly Performance */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Quarterly Returns (%)</h2>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={PERF}>
                  <XAxis dataKey="m" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }} itemStyle={{ color: '#60a5fa' }} />
                  <Bar dataKey="return" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Return %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Asset Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">Asset Breakdown</h2>
              <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ Add Asset</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Asset</th>
                    <th className="text-left py-2 pr-4">Type</th>
                    <th className="text-left py-2 pr-4">Value</th>
                    <th className="text-left py-2 pr-4">Change</th>
                    <th className="text-left py-2">Allocation</th>
                  </tr>
                </thead>
                <tbody>
                  {ASSETS.map((a, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white font-medium text-xs">{a.name}</td>
                      <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-400 text-xs px-2 py-0.5 rounded">{a.type}</span></td>
                      <td className="py-3 pr-4 text-white text-xs font-mono">{a.value}</td>
                      <td className="py-3 pr-4">
                        <span className={`text-xs font-medium ${a.positive ? 'text-green-400' : 'text-red-400'}`}>{a.change}</span>
                      </td>
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-20 bg-slate-800 rounded-full h-1.5">
                            <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${a.alloc}%` }} />
                          </div>
                          <span className="text-xs text-slate-500">{a.alloc}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}