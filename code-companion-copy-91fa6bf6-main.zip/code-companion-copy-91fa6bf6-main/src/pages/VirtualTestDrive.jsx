import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Loader2, Sparkles, Play, Pause } from 'lucide-react';

export default function VirtualTestDrive() {
  const navigate = useNavigate();
  const location = useLocation();
  const { modelName } = location.state || {};

  const [testDrive, setTestDrive] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeSection, setActiveSection] = useState('start');

  useEffect(() => {
    if (!modelName) {
      navigate(-1);
      return;
    }
    generateTestDrive();
  }, [modelName]);

  const generateTestDrive = async () => {
    setLoading(true);
    try {
      const prompt = `Create an immersive, personalized virtual test drive experience for the ${modelName} Bentley. Include vivid, sensory-rich descriptions.

Generate JSON with:
{
  "model_name": "string",
  "experience_sections": [
    {
      "title": "string",
      "scenario": "string (vivid description of what you're experiencing)",
      "sensory_details": {
        "sight": "what you see",
        "sound": "what you hear",
        "feel": "what you feel/haptics",
        "smell": "what you smell"
      },
      "performance_highlights": ["string"],
      "comfort_notes": "string"
    }
  ],
  "overall_impression": "string",
  "recommended_configurations": ["string"],
  "why_exceptional": ["string"],
  "next_steps": ["string"],
  "experience_duration_minutes": number
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            model_name: { type: 'string' },
            experience_sections: { type: 'array' },
            overall_impression: { type: 'string' },
            recommended_configurations: { type: 'array', items: { type: 'string' } },
            why_exceptional: { type: 'array', items: { type: 'string' } },
            next_steps: { type: 'array', items: { type: 'string' } },
            experience_duration_minutes: { type: 'number' }
          }
        }
      });

      setTestDrive(result);
      setActiveSection('start');
    } catch (error) {
      console.error('Error generating test drive:', error);
      alert('Failed to generate virtual test drive. Please try again.');
      navigate(-1);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Preparing Your Virtual Test Drive</h2>
          <p className="text-slate-400">Generating immersive experience for {modelName}...</p>
        </div>
      </div>
    );
  }

  if (!testDrive) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-blue-400 hover:text-blue-300 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-4xl font-bold text-white mb-3 flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-purple-500" />
            Virtual Test Drive - {testDrive.model_name}
          </h1>
          <p className="text-slate-400">Experience {testDrive.experience_duration_minutes} minutes of immersive driving</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="sticky top-12 space-y-3">
              <button
                onClick={() => setActiveSection('start')}
                className={`w-full text-left px-4 py-3 rounded-lg border transition-all ${
                  activeSection === 'start'
                    ? 'bg-purple-600 border-purple-500 text-white'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="font-semibold">Experience Overview</div>
              </button>

              {testDrive.experience_sections?.map((section, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveSection(`section-${idx}`)}
                  className={`w-full text-left px-4 py-3 rounded-lg border transition-all ${
                    activeSection === `section-${idx}`
                      ? 'bg-purple-600 border-purple-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="font-semibold text-sm">{section.title}</div>
                </button>
              ))}

              <button
                onClick={() => setActiveSection('summary')}
                className={`w-full text-left px-4 py-3 rounded-lg border transition-all ${
                  activeSection === 'summary'
                    ? 'bg-purple-600 border-purple-500 text-white'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="font-semibold text-sm">Summary & Next Steps</div>
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeSection === 'start' && (
              <div className="space-y-8">
                <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/50 rounded-lg p-8">
                  <h2 className="text-3xl font-bold text-white mb-4">Your Immersive Experience Awaits</h2>
                  <p className="text-slate-300 mb-6 text-lg leading-relaxed">
                    Welcome to an exclusive virtual test drive of the {testDrive.model_name}. Over the next {testDrive.experience_duration_minutes} minutes, 
                    you'll experience various driving scenarios that showcase the vehicle's capabilities, comfort, and distinctive character.
                  </p>

                  {testDrive.why_exceptional && (
                    <div className="mb-8">
                      <h3 className="text-lg font-semibold text-white mb-4">Why This Model Stands Out</h3>
                      <ul className="space-y-2">
                        {testDrive.why_exceptional.map((point, i) => (
                          <li key={i} className="text-slate-300 flex items-start gap-3">
                            <span className="text-purple-400 mt-1">✨</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <Button
                    onClick={() => setActiveSection('section-0')}
                    className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-3"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Start Experience
                  </Button>
                </div>
              </div>
            )}

            {activeSection.startsWith('section-') && (
              <div className="space-y-6">
                {testDrive.experience_sections?.[parseInt(activeSection.split('-')[1])] && (() => {
                  const section = testDrive.experience_sections[parseInt(activeSection.split('-')[1])];
                  return (
                    <>
                      <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
                        <h2 className="text-3xl font-bold text-white mb-2">{section.title}</h2>
                        <p className="text-slate-400 mb-6 italic">Scenario: {section.scenario}</p>

                        <div className="prose prose-invert max-w-none mb-8">
                          <p className="text-slate-300 leading-relaxed text-lg">{section.scenario}</p>
                        </div>

                        {section.sensory_details && (
                          <div className="grid md:grid-cols-2 gap-4 mb-8">
                            <div className="bg-slate-700/50 rounded p-4">
                              <h4 className="text-white font-semibold mb-2">👁️ What You See</h4>
                              <p className="text-slate-300 text-sm">{section.sensory_details.sight}</p>
                            </div>
                            <div className="bg-slate-700/50 rounded p-4">
                              <h4 className="text-white font-semibold mb-2">🔊 What You Hear</h4>
                              <p className="text-slate-300 text-sm">{section.sensory_details.sound}</p>
                            </div>
                            <div className="bg-slate-700/50 rounded p-4">
                              <h4 className="text-white font-semibold mb-2">🤚 What You Feel</h4>
                              <p className="text-slate-300 text-sm">{section.sensory_details.feel}</p>
                            </div>
                            <div className="bg-slate-700/50 rounded p-4">
                              <h4 className="text-white font-semibold mb-2">👃 What You Smell</h4>
                              <p className="text-slate-300 text-sm">{section.sensory_details.smell}</p>
                            </div>
                          </div>
                        )}

                        {section.performance_highlights && (
                          <div className="mb-8">
                            <h3 className="text-white font-semibold mb-3">Performance Highlights</h3>
                            <ul className="space-y-2">
                              {section.performance_highlights.map((highlight, i) => (
                                <li key={i} className="text-slate-300 flex items-start gap-2">
                                  <span className="text-green-400 mt-1">⚡</span>
                                  <span>{highlight}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {section.comfort_notes && (
                          <div className="bg-purple-600/20 border border-purple-500/30 rounded p-4">
                            <h3 className="text-white font-semibold mb-2">Comfort Notes</h3>
                            <p className="text-slate-300">{section.comfort_notes}</p>
                          </div>
                        )}
                      </div>

                      {/* Navigation */}
                      <div className="flex gap-4">
                        {parseInt(activeSection.split('-')[1]) > 0 && (
                          <Button
                            onClick={() => setActiveSection(`section-${parseInt(activeSection.split('-')[1]) - 1}`)}
                            variant="outline"
                            className="flex-1"
                          >
                            ← Previous Section
                          </Button>
                        )}
                        {parseInt(activeSection.split('-')[1]) < testDrive.experience_sections.length - 1 && (
                          <Button
                            onClick={() => setActiveSection(`section-${parseInt(activeSection.split('-')[1]) + 1}`)}
                            className="flex-1 bg-purple-600 hover:bg-purple-700"
                          >
                            Next Section →
                          </Button>
                        )}
                        {parseInt(activeSection.split('-')[1]) === testDrive.experience_sections.length - 1 && (
                          <Button
                            onClick={() => setActiveSection('summary')}
                            className="flex-1 bg-purple-600 hover:bg-purple-700"
                          >
                            See Summary →
                          </Button>
                        )}
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {activeSection === 'summary' && (
              <div className="space-y-8">
                {testDrive.overall_impression && (
                  <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/50 rounded-lg p-8">
                    <h2 className="text-2xl font-bold text-white mb-4">Overall Impression</h2>
                    <p className="text-slate-300 leading-relaxed text-lg">{testDrive.overall_impression}</p>
                  </div>
                )}

                {testDrive.recommended_configurations && (
                  <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
                    <h3 className="text-xl font-semibold text-white mb-4">Recommended Configurations</h3>
                    <div className="space-y-2">
                      {testDrive.recommended_configurations.map((config, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-slate-700/50 rounded">
                          <span className="text-blue-400 mt-1">💎</span>
                          <span className="text-slate-300">{config}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {testDrive.next_steps && (
                  <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
                    <h3 className="text-xl font-semibold text-white mb-4">Next Steps</h3>
                    <ol className="space-y-3">
                      {testDrive.next_steps.map((step, i) => (
                        <li key={i} className="flex gap-3 text-slate-300">
                          <span className="font-bold text-purple-400">{i + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                )}

                <div className="flex gap-4">
                  <Button
                    onClick={() => navigate(-1)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    Back to Recommendations
                  </Button>
                  <Button
                    onClick={() => navigate('/')}
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    Return to Home
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}