import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import { Key, Plus, CheckCircle, AlertTriangle, XCircle, Shield } from 'lucide-react';

const NAV = [
  { category: 'HIERARCHY', items: [
    { label: 'Organizations', path: '/organizations', icon: '🏢' },
    { label: 'Licenses', path: '/licenses', icon: '🔑' },
    { label: 'Admin', path: '/admin', icon: '⚙' },
  ]},
];

const STATUS_STYLE = {
  active: 'bg-green-500/10 text-green-400 border-green-500/20',
  trial: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  expired: 'bg-red-500/10 text-red-400 border-red-500/20',
  suspended: 'bg-red-500/10 text-red-400 border-red-500/20',
  grace_period: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
};

const PLAN_STYLE = {
  free: 'bg-slate-700 text-slate-300',
  starter: 'bg-blue-500/10 text-blue-400',
  professional: 'bg-purple-500/10 text-purple-400',
  enterprise: 'bg-yellow-500/10 text-yellow-400',
};

function sha256Preview(input) {
  // Simple visual fingerprint preview — real hashing happens server-side
  return input ? `sha256:${input.slice(0, 6)}...${input.slice(-4)}` : '';
}

export default function Licenses() {
  const { currentUser } = useAuth();
  const [licenses, setLicenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showActivate, setShowActivate] = useState(false);
  const [form, setForm] = useState({ organization_id: '', organization_name: '', plan: 'starter', raw_key: '', expires_at: '', seat_limit: 5 });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.License.list('-created_date', 100).then(data => {
      setLicenses(data);
      setLoading(false);
    });
    const unsub = base44.entities.License.subscribe(event => {
      if (event.type === 'create') setLicenses(p => [event.data, ...p]);
      else if (event.type === 'update') setLicenses(p => p.map(l => l.id === event.id ? event.data : l));
      else if (event.type === 'delete') setLicenses(p => p.filter(l => l.id !== event.id));
    });
    return unsub;
  }, []);

  const activate = async () => {
    if (!form.organization_name.trim() || !form.raw_key.trim()) return;
    setSaving(true);
    // Store fingerprint only — never raw key
    const fingerprint = sha256Preview(form.raw_key + form.organization_id);
    await base44.entities.License.create({
      organization_id: form.organization_id,
      organization_name: form.organization_name,
      plan: form.plan,
      status: 'active',
      key_fingerprint: fingerprint,
      activated_by: currentUser?.email,
      activated_at: new Date().toISOString(),
      expires_at: form.expires_at || null,
      seat_limit: form.seat_limit,
      seats_used: 0,
      deployment_quota: form.plan === 'enterprise' ? 9999 : form.plan === 'professional' ? 500 : 100,
      deployments_used: 0,
    });
    setForm({ organization_id: '', organization_name: '', plan: 'starter', raw_key: '', expires_at: '', seat_limit: 5 });
    setShowActivate(false);
    setSaving(false);
  };

  const suspend = async (license) => {
    await base44.entities.License.update(license.id, { status: 'suspended' });
  };

  const counts = {
    total: licenses.length,
    active: licenses.filter(l => l.status === 'active').length,
    trial: licenses.filter(l => l.status === 'trial').length,
    expired: licenses.filter(l => ['expired', 'suspended'].includes(l.status)).length,
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Platform Admin" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-yellow-400" /> License Manager
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">Per-org license activation · keys never stored raw</p>
          </div>
          <button onClick={() => setShowActivate(true)}
            className="bg-yellow-600 hover:bg-yellow-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> Activate License
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-6 py-4 border-b border-slate-800">
          {[
            { label: 'Total', value: counts.total, color: 'text-white' },
            { label: 'Active', value: counts.active, color: 'text-green-400' },
            { label: 'Trial', value: counts.trial, color: 'text-orange-400' },
            { label: 'Expired/Suspended', value: counts.expired, color: 'text-red-400' },
          ].map(k => (
            <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {loading && <div className="text-center text-slate-500 py-12">Loading licenses...</div>}
          {!loading && licenses.length === 0 && (
            <div className="text-center text-slate-600 py-16">
              <Shield className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <div className="text-sm">No licenses activated.</div>
            </div>
          )}
          {licenses.map(lic => (
            <div key={lic.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-white font-semibold text-sm">{lic.organization_name || lic.organization_id}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full border ${STATUS_STYLE[lic.status]}`}>{lic.status}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${PLAN_STYLE[lic.plan]}`}>{lic.plan}</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                    {[
                      ['Seats', `${lic.seats_used || 0} / ${lic.seat_limit || 5}`],
                      ['Deployments', `${lic.deployments_used || 0} / ${lic.deployment_quota || 100}`],
                      ['Activated', lic.activated_at ? new Date(lic.activated_at).toLocaleDateString() : '—'],
                      ['Expires', lic.expires_at ? new Date(lic.expires_at).toLocaleDateString() : 'Never'],
                    ].map(([k, v]) => (
                      <div key={k} className="bg-slate-800 rounded-lg px-3 py-2">
                        <div className="text-xs text-slate-500">{k}</div>
                        <div className="text-white text-xs font-medium">{v}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 text-slate-600 text-xs font-mono">{lic.key_fingerprint}</div>
                </div>
                <div className="flex gap-2 shrink-0">
                  {lic.status === 'active' && (
                    <button onClick={() => suspend(lic)}
                      className="bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs px-2 py-1.5 rounded-lg transition">
                      Suspend
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showActivate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold flex items-center gap-2"><Key className="w-4 h-4 text-yellow-400" /> Activate License</h3>
              <button onClick={() => setShowActivate(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 text-xs text-yellow-400">
              ⚠ The raw license key is never stored. Only a SHA-256 fingerprint is persisted.
            </div>
            <input value={form.organization_name} onChange={e => setForm(f => ({ ...f, organization_name: e.target.value }))}
              placeholder="Organization name *"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500" />
            <input value={form.organization_id} onChange={e => setForm(f => ({ ...f, organization_id: e.target.value }))}
              placeholder="Organization ID (optional)"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500" />
            <input type="password" value={form.raw_key} onChange={e => setForm(f => ({ ...f, raw_key: e.target.value }))}
              placeholder="License key * (will not be stored)"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500" />
            <div className="flex gap-3">
              <select value={form.plan} onChange={e => setForm(f => ({ ...f, plan: e.target.value }))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500">
                {['free', 'starter', 'professional', 'enterprise'].map(p => <option key={p}>{p}</option>)}
              </select>
              <input type="number" value={form.seat_limit} onChange={e => setForm(f => ({ ...f, seat_limit: parseInt(e.target.value) }))}
                className="w-24 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500"
                placeholder="Seats" />
            </div>
            <input type="date" value={form.expires_at} onChange={e => setForm(f => ({ ...f, expires_at: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 text-slate-400 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500" />
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowActivate(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={activate} disabled={saving || !form.organization_name.trim() || !form.raw_key.trim()}
                className="flex-1 bg-yellow-600 hover:bg-yellow-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">
                {saving ? 'Activating...' : 'Activate'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}