import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useRoleGuard } from '@/hooks/useRoleGuard';
import { useAuth } from '@/lib/AuthContext';
import { Link } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';

const NAV = [
  { category: 'ADMIN', items: [
    { label: 'Overview', path: '/admin', icon: '⚙' },
    { label: 'Bentley Connection', path: '/admin', icon: '🔑' },
    { label: 'Webhooks', path: '/admin', icon: '🪝' },
    { label: 'Alert Rules', path: '/admin', icon: '🔔' },
    { label: 'User Management', path: '/admin', icon: '👥' },
    { label: 'Diagnostics', path: '/admin', icon: '🔍' },
    { label: 'Launch Readiness', path: '/admin', icon: '🚀' },
  ]},
  { category: 'PLATFORM', items: [
    { label: 'API Docs', path: '/admin', icon: '📖' },
    { label: 'Health Monitor', path: '/admin', icon: '💚' },
    { label: 'Deployments', path: '/itwin-apps', icon: '🚢' },
  ]},
];

const USERS = [
  { email: 'admin@bentley.com', name: 'Platform Admin', role: 'Admin', status: 'Active', lastLogin: '2m ago' },
  { email: 'ops@bentley.com', name: 'Ops Engineer', role: 'Operator', status: 'Active', lastLogin: '1h ago' },
  { email: 'client@bentley.com', name: 'Client User', role: 'Viewer', status: 'Active', lastLogin: '3d ago' },
];

const ALERT_RULES = [
  { name: 'High Error Rate', condition: 'errors > 10/min', channels: 'Slack, Email', status: 'Active' },
  { name: 'Sync Failure', condition: 'runFailed events', channels: 'PagerDuty', status: 'Active' },
  { name: 'iTwin Created', condition: 'iTwinCreated event', channels: 'Webhook', status: 'Paused' },
];

const RECENT_DELIVERIES = [
  { time: '14:22:01', ip: '52.14.122.8', sig: true, status: 'processed' },
  { time: '14:19:44', ip: '52.14.122.8', sig: true, status: 'processed' },
  { time: '14:15:30', ip: '52.14.122.8', sig: false, status: 'rejected' },
  { time: '14:10:11', ip: '34.201.5.92', sig: true, status: 'processed' },
];

const SERVICE_CONFIGS = [
  { icon: '🐳', name: 'Docker Runtime', status: 'Configurable', desc: 'Container orchestration via Docker. Set ENABLE_DOCKER=true and mount socket to activate.', statusColor: 'text-yellow-400 bg-yellow-500/10' },
  { icon: '☸', name: 'Kubernetes', status: 'Control Plane', desc: 'K8s control-plane.yaml deployed. Portainer stack available for GUI management.', statusColor: 'text-blue-400 bg-blue-500/10' },
  { icon: '🚨', name: 'Alert Delivery', status: 'Email ready', desc: 'Multi-channel: Slack, Discord, PagerDuty, Email, Webhook via event bus.', statusColor: 'text-green-400 bg-green-500/10' },
  { icon: '🔐', name: 'License Manager', status: 'Active', desc: 'Per-org license enforcement. Quota checks on deployments, environments, and seats.', statusColor: 'text-green-400 bg-green-500/10' },
];

const LAUNCH_CHECKS = [
  { label: 'DATABASE_URL configured', ok: true },
  { label: 'SECRET_KEY set (not default)', ok: true },
  { label: 'ENABLE_DOCKER flag set', ok: false },
  { label: 'ALLOWED_ORIGINS restricted', ok: true },
  { label: 'Bentley credentials set', ok: true },
  { label: 'Webhook secret present', ok: true },
  { label: 'JWT key configured', ok: true },
  { label: 'Cookie security enabled', ok: true },
  { label: 'Alert routing set', ok: false },
  { label: 'Observability enabled', ok: false },
];

export default function AdminDashboard() {
  const { isAdmin, currentUser } = useRoleGuard('admin', '/');
  const [bentleyId, setBentleyId] = useState('');
  const [bentleySecret, setBentleySecret] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [purgeRange, setPurgeRange] = useState('30');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('user');
  const [inviting, setInviting] = useState(false);
  const [inviteResult, setInviteResult] = useState(null);
  const [webhookCopied, setWebhookCopied] = useState(false);
  const [webhookDeliveries, setWebhookDeliveries] = useState([]);
  const [orgs, setOrgs] = useState([]);
  const [deployments, setDeployments] = useState([]);

  useEffect(() => {
    Promise.all([
      base44.entities.WebhookDelivery.list('-created_date', 20),
      base44.entities.Organization.list('-created_date', 50),
      base44.entities.Deployment.list('-created_date', 50),
    ]).then(([wh, og, dp]) => {
      setWebhookDeliveries(wh);
      setOrgs(og);
      setDeployments(dp);
    });
    const unsub = base44.entities.WebhookDelivery.subscribe(e => {
      if (e.type === 'create') setWebhookDeliveries(p => [e.data, ...p]);
      else if (e.type === 'update') setWebhookDeliveries(p => p.map(d => d.id === e.id ? e.data : d));
    });
    return unsub;
  }, []);

  const passedChecks = LAUNCH_CHECKS.filter(c => c.ok).length;

  const handleInvite = async () => {
    if (!inviteEmail.trim()) return;
    setInviting(true);
    setInviteResult(null);
    await base44.users.inviteUser(inviteEmail.trim(), inviteRole);
    setInviteResult({ ok: true, email: inviteEmail });
    setInviteEmail('');
    setInviting(false);
  };

  const copyWebhook = () => {
    navigator.clipboard.writeText('https://your-app.base44.app/webhook');
    setWebhookCopied(true);
    setTimeout(() => setWebhookCopied(false), 2000);
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Admin" />
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-800">
          <div>
            <h1 className="text-2xl font-bold text-white">Admin Settings</h1>
            <p className="text-slate-400 text-sm mt-1">Bentley integration, webhooks, alerts and platform management</p>
          </div>
          <div className="flex gap-2">
            <button className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">↻ Stats</button>
            <a href="#api-docs" className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">API Docs ↗</a>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            {[
              { icon: '🏢', label: 'Organizations', value: orgs.length, color: 'text-purple-400' },
              { icon: '🚀', label: 'Deployments', value: deployments.length, color: 'text-green-400' },
              { icon: '✅', label: 'Deployed', value: deployments.filter(d => d.status === 'deployed').length, color: 'text-teal-400' },
              { icon: '🪝', label: 'Webhook Events', value: webhookDeliveries.length, color: 'text-blue-400' },
              { icon: '⏱', label: 'Uptime', value: '99.9%', color: 'text-orange-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className={`text-xl ${k.color}`}>{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className="text-xl font-bold text-white">{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Architecture Flow */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h2 className="text-white font-semibold mb-4 text-sm">Service Architecture Flow</h2>
            <div className="flex items-center gap-2 flex-wrap">
              {[
                { label: 'Organization', color: 'bg-purple-500/10 border-purple-500/30 text-purple-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'Project', color: 'bg-blue-500/10 border-blue-500/30 text-blue-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'Environment', color: 'bg-teal-500/10 border-teal-500/30 text-teal-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'Deployment', color: 'bg-green-500/10 border-green-500/30 text-green-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'License Check', color: 'bg-orange-500/10 border-orange-500/30 text-orange-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'Event Bus', color: 'bg-red-500/10 border-red-500/30 text-red-300' },
                { label: '→', color: 'text-slate-600 text-lg bg-transparent border-transparent' },
                { label: 'Alert Delivery', color: 'bg-pink-500/10 border-pink-500/30 text-pink-300' },
              ].map((step, i) => (
                <span key={i} className={`text-xs px-3 py-1.5 rounded-lg border font-medium ${step.color}`}>{step.label}</span>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: 'API Layer', value: 'FastAPI + Pydantic', icon: '⚡' },
                { label: 'Database', value: 'PostgreSQL / SQLite', icon: '🗄' },
                { label: 'Auth', value: 'JWT (60 min TTL)', icon: '🔐' },
                { label: 'Runtime', value: 'Docker / K8s', icon: '🐳' },
              ].map(s => (
                <div key={s.label} className="bg-slate-800 rounded-lg px-3 py-2 flex items-center gap-2">
                  <span className="text-base">{s.icon}</span>
                  <div>
                    <div className="text-xs text-slate-500">{s.label}</div>
                    <div className="text-white text-xs font-medium">{s.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Bentley Connection */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Bentley Connection</h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400">Configured</span>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Client ID</label>
                  <input value={bentleyId} onChange={e => setBentleyId(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                    placeholder="BENTLEY_CLIENT_ID" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Client Secret</label>
                  <input type="password" value={bentleySecret} onChange={e => setBentleySecret(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                    placeholder="BENTLEY_CLIENT_SECRET" />
                </div>
                <div className="flex gap-2 pt-1">
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm py-2 rounded-lg transition">Test Connection</button>
                  <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm py-2 rounded-lg transition">Fetch iTwins</button>
                </div>
              </div>
            </div>

            {/* Webhook Endpoint */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Webhook Endpoint</h2>
              <p className="text-slate-400 text-sm mb-3">Register this URL in your Bentley webhook subscription:</p>
              <div className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 flex items-center justify-between gap-2 mb-3">
                <code className="text-blue-400 text-xs truncate">https://your-app.base44.app/webhook</code>
                <button onClick={copyWebhook} className="text-slate-400 hover:text-white text-xs shrink-0">{webhookCopied ? '✓ Copied' : 'Copy'}</button>
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">Webhook Secret (env: WEBHOOK_SECRET)</label>
                <input type="password" className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500" placeholder="••••••••" />
              </div>
              <div className="flex gap-2 mt-3">
                <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm py-2 rounded-lg transition">List Webhooks</button>
                <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm py-2 rounded-lg transition">Register New →</button>
              </div>
            </div>
          </div>

          {/* Alert Rules */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">Alert Rules</h2>
              <button onClick={() => setShowAlertModal(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">
                + New Rule
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Name</th>
                    <th className="text-left py-2 pr-4">Condition</th>
                    <th className="text-left py-2 pr-4">Channels</th>
                    <th className="text-left py-2 pr-4">Status</th>
                    <th className="text-left py-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {ALERT_RULES.map((r, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white font-medium">{r.name}</td>
                      <td className="py-3 pr-4 text-slate-400 text-xs font-mono">{r.condition}</td>
                      <td className="py-3 pr-4 text-slate-400 text-xs">{r.channels}</td>
                      <td className="py-3 pr-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === 'Active' ? 'bg-green-500/10 text-green-400' : 'bg-slate-800 text-slate-400'}`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="py-3">
                        <div className="flex gap-2">
                          <button className="text-xs text-blue-400 hover:text-blue-300">Edit</button>
                          <button className="text-xs text-slate-400 hover:text-slate-300">{r.status === 'Active' ? 'Pause' : 'Resume'}</button>
                          <button className="text-xs text-red-400 hover:text-red-300">Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Data Management */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Data Management</h2>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-slate-800 rounded-lg p-3 text-center">
                  <div className="text-xs text-slate-500 mb-1">Deliveries</div>
                  <div className="text-lg font-bold text-white">4,291</div>
                </div>
                <div className="bg-slate-800 rounded-lg p-3 text-center">
                  <div className="text-xs text-slate-500 mb-1">Processed OK</div>
                  <div className="text-lg font-bold text-green-400">4,287</div>
                </div>
                <div className="bg-slate-800 rounded-lg p-3 text-center">
                  <div className="text-xs text-slate-500 mb-1">Errors</div>
                  <div className="text-lg font-bold text-red-400">4</div>
                </div>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-slate-400 text-sm">Delete events older than</span>
                <select value={purgeRange} onChange={e => setPurgeRange(e.target.value)}
                  className="bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs">
                  <option value="7">7 days</option>
                  <option value="30">30 days</option>
                  <option value="60">60 days</option>
                  <option value="90">90 days</option>
                </select>
                <button className="bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs px-3 py-1 rounded-lg transition">🗑 Purge</button>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm py-2 rounded-lg transition">⚡ Seed Demo Events</button>
                <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm py-2 rounded-lg transition">📥 Export CSV</button>
              </div>
            </div>

            {/* Bentley Diagnostics */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Bentley Diagnostics</h2>
                <Link to="/admin" className="text-blue-400 text-xs hover:text-blue-300">Open Full Diagnostics →</Link>
              </div>
              <div className="space-y-3 mb-4">
                {[
                  { icon: '🔑', label: 'Client ID', value: 'BENT-****-7a2f' },
                  { icon: '🔒', label: 'Client Secret', value: '✓ Present' },
                  { icon: '🪝', label: 'Webhook Secret', value: '✓ Present' },
                  { icon: '🛡', label: 'Sig Verification', value: '✓ Enabled' },
                ].map(d => (
                  <div key={d.label} className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400 text-sm">{d.icon} {d.label}</span>
                    <span className="text-white text-xs font-mono">{d.value}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs py-2 rounded-lg transition">⚡ Test OAuth</button>
                <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs py-2 rounded-lg transition">Copy Callback URL</button>
              </div>
            </div>
          </div>

          {/* User Management */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">User Management</h2>
              <button onClick={() => setShowInviteModal(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">
                + Invite User
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Email</th>
                    <th className="text-left py-2 pr-4">Name</th>
                    <th className="text-left py-2 pr-4">Role</th>
                    <th className="text-left py-2 pr-4">Status</th>
                    <th className="text-left py-2 pr-4">Last Login</th>
                    <th className="text-left py-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {USERS.map((u, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-blue-400 text-xs">{u.email}</td>
                      <td className="py-3 pr-4 text-white text-xs">{u.name}</td>
                      <td className="py-3 pr-4">
                        <span className="bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded">{u.role}</span>
                      </td>
                      <td className="py-3 pr-4">
                        <span className="bg-green-500/10 text-green-400 text-xs px-2 py-0.5 rounded-full">{u.status}</span>
                      </td>
                      <td className="py-3 pr-4 text-slate-500 text-xs">{u.lastLogin}</td>
                      <td className="py-3">
                        <div className="flex gap-2">
                          <button className="text-xs text-blue-400 hover:text-blue-300">Edit</button>
                          <button className="text-xs text-slate-400 hover:text-slate-300">Reset PW</button>
                          <button className="text-xs text-red-400 hover:text-red-300">Disable</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Recent Webhook Deliveries — real entity data */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Webhook Delivery Log</h2>
                <span className="text-slate-500 text-xs">{webhookDeliveries.length} events</span>
              </div>
              {webhookDeliveries.length === 0 ? (
                <div className="text-center text-slate-600 py-6 text-xs">No webhook deliveries yet. Deliveries are logged when Bentley events arrive.</div>
              ) : (
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-slate-500 uppercase border-b border-slate-800">
                      <th className="text-left py-2 pr-3">Time</th>
                      <th className="text-left py-2 pr-3">Event Type</th>
                      <th className="text-left py-2 pr-3">Sig</th>
                      <th className="text-left py-2 pr-3">Status</th>
                      <th className="text-left py-2">Duration</th>
                    </tr>
                  </thead>
                  <tbody>
                    {webhookDeliveries.slice(0, 10).map((d) => (
                      <tr key={d.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="py-2 pr-3 text-slate-400 font-mono">{new Date(d.created_date).toLocaleTimeString()}</td>
                        <td className="py-2 pr-3 text-slate-300 text-xs">{d.event_type || '—'}</td>
                        <td className="py-2 pr-3">
                          <span className={d.signature_valid ? 'text-green-400' : 'text-red-400'}>{d.signature_valid ? '✓' : '✗'}</span>
                        </td>
                        <td className="py-2 pr-3">
                          <span className={`px-2 py-0.5 rounded-full ${
                            d.status === 'processed' ? 'bg-green-500/10 text-green-400' :
                            d.status === 'rejected' ? 'bg-red-500/10 text-red-400' :
                            'bg-yellow-500/10 text-yellow-400'
                          }`}>{d.status}</span>
                        </td>
                        <td className="py-2 text-slate-600">{d.duration_ms ? `${d.duration_ms}ms` : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Launch Readiness */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Launch Readiness</h2>
                <span className={`text-xs px-2 py-0.5 rounded-full ${passedChecks >= 8 ? 'bg-green-500/10 text-green-400' : 'bg-orange-500/10 text-orange-400'}`}>
                  {passedChecks}/{LAUNCH_CHECKS.length} Passed
                </span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 mb-4">
                <div className="bg-green-500 h-2 rounded-full transition-all" style={{ width: `${(passedChecks / LAUNCH_CHECKS.length) * 100}%` }} />
              </div>
              <div className="space-y-2 max-h-52 overflow-y-auto">
                {LAUNCH_CHECKS.map((c, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className={c.ok ? 'text-green-400' : 'text-red-400'}>{c.ok ? '✓' : '✗'}</span>
                    <span className={`text-xs ${c.ok ? 'text-slate-400' : 'text-red-300'}`}>{c.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Service Configuration */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Service Configuration Readiness</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {SERVICE_CONFIGS.map(s => (
                <div key={s.name} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="text-2xl mb-2">{s.icon}</div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-white text-sm font-medium">{s.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${s.statusColor}`}>{s.status}</span>
                  </div>
                  <p className="text-slate-500 text-xs leading-relaxed">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Platform Info */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Platform Info</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              {[
                { label: 'API Version', value: '1.4.0' },
                { label: 'Environment', value: 'Production' },
                { label: 'Database', value: 'PostgreSQL' },
                { label: 'JWT Expire', value: '60 min' },
              ].map(p => (
                <div key={p.label} className="bg-slate-800 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">{p.label}</div>
                  <div className="text-white font-mono text-sm">{p.value}</div>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {['Launch Readiness →', 'API Docs →', 'Health →', 'Deployments →'].map(btn => (
                <button key={btn} className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">{btn}</button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-slate-800">
              <h3 className="text-white font-bold">Invite User</h3>
              <button onClick={() => setShowInviteModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Email</label>
                <input value={inviteEmail} onChange={e => setInviteEmail(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500" placeholder="user@example.com" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">Role</label>
                <select value={inviteRole} onChange={e => setInviteRole(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm">
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              {inviteResult?.ok && (
                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-green-400 text-xs">
                  ✓ Invite sent to {inviteResult.email}
                </div>
              )}
            </div>
            <div className="flex gap-3 p-5 border-t border-slate-800">
              <button onClick={() => { setShowInviteModal(false); setInviteResult(null); }} className="flex-1 bg-slate-800 text-slate-300 rounded-lg py-2 text-sm">Close</button>
              <button onClick={handleInvite} disabled={inviting || !inviteEmail.trim()}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-lg py-2 text-sm">
                {inviting ? 'Sending...' : 'Send Invite'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}