import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { base44 } from '@/api/base44Client';

const NAV = [
  { category: 'CONTROL PLANE', items: [
    { label: 'Overview', path: '/client', icon: '🌐' },
    { label: 'Website Studio', path: '/client', icon: '🎨' },
    { label: 'Infrastructure', path: '/client', icon: '🏗️' },
    { label: 'Marketplace', path: '/client', icon: '🛒' },
    { label: 'Environments', path: '/client', icon: '⚙' },
  ]},
  { category: 'RESOURCES', items: [
    { label: 'Documentation', path: '/client', icon: '📖' },
    { label: 'Support', path: '/client', icon: '💬' },
  ]},
];

const MODULES = [
  { name: 'Webhook Gateway', status: 'Running', summary: 'Receives and validates Bentley platform webhook events via HMAC verification.', ok: true },
  { name: 'Event Processor', status: 'Running', summary: 'Parses incoming events, extracts metadata, and routes to alert evaluation engine.', ok: true },
  { name: 'Alert Engine', status: 'Running', summary: 'Evaluates alert rules and dispatches to Slack, Email, PagerDuty, and webhooks.', ok: true },
  { name: 'Auth Module', status: 'Running', summary: 'JWT session management with cookie-based auth and role-based access control.', ok: true },
  { name: 'Data Retention', status: 'Running', summary: 'Automated event cleanup based on configurable retention policy.', ok: true },
  { name: 'Observability', status: 'Planned', summary: 'Sentry/Datadog integration for error tracking and APM. Configure SENTRY_DSN.', ok: false },
  { name: 'Rate Limiter', status: 'Running', summary: 'Per-IP webhook rate limiting at 60 req/min via in-memory sliding window.', ok: true },
  { name: 'Marketplace Sync', status: 'Coming Soon', summary: 'Partner solutions and news card integration for the enterprise catalog.', ok: false },
];

const ENV_STATUS_MAP = { healthy: 'Healthy', degraded: 'Degraded', down: 'Down', deploying: 'Deploying', idle: 'Idle' };
const ENV_STATUS_COLOR = { healthy: 'bg-green-500/10 text-green-400', degraded: 'bg-yellow-500/10 text-yellow-400', down: 'bg-red-500/10 text-red-400', deploying: 'bg-blue-500/10 text-blue-400', idle: 'bg-slate-700 text-slate-400' };

const STUDIO_ACTIONS = [
  { icon: '🌐', name: 'Website Studio', desc: 'Manage platform domains and content.', cta: 'Launch Studio', color: 'border-blue-500/30 hover:border-blue-500' },
  { icon: '🏗️', name: 'Infrastructure', desc: 'Cloud clusters and global resources.', cta: 'Open Console', color: 'border-purple-500/30 hover:border-purple-500' },
  { icon: '🛒', name: 'Marketplace', desc: 'Partner solutions and news cards.', cta: 'Coming Soon', color: 'border-teal-500/30 hover:border-teal-500', disabled: true },
];

const STATUS_COLORS = {
  'Running': 'bg-green-500/10 text-green-400',
  'Healthy': 'bg-green-500/10 text-green-400',
  'Active': 'bg-blue-500/10 text-blue-400',
  'Planned': 'bg-slate-700 text-slate-400',
  'Coming Soon': 'bg-slate-700 text-slate-400',
};

export default function ClientDashboard() {
  const [moduleFilter, setModuleFilter] = useState('');
  const [environments, setEnvironments] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [licenses, setLicenses] = useState([]);

  useEffect(() => {
    Promise.all([
      base44.entities.Environment.list('-created_date', 20),
      base44.entities.Deployment.list('-created_date', 10),
      base44.entities.License.list('-created_date', 10),
    ]).then(([envs, deps, lics]) => {
      setEnvironments(envs);
      setDeployments(deps);
      setLicenses(lics);
    });
  }, []);

  const filteredModules = MODULES.filter(m =>
    m.name.toLowerCase().includes(moduleFilter.toLowerCase()) ||
    m.summary.toLowerCase().includes(moduleFilter.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Control Plane" />
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">Enterprise Control Plane</h1>
          <p className="text-slate-400 text-sm mt-1">Enterprise execution layer for website studio, infrastructure, marketplace, client delivery and environments.</p>
        </div>

        <div className="p-6 space-y-6">
          {/* Top Actions */}
          <div className="grid sm:grid-cols-3 gap-4">
            {STUDIO_ACTIONS.map(a => (
              <div key={a.name} className={`bg-slate-900 border rounded-xl p-6 transition ${a.color}`}>
                <div className="text-3xl mb-3">{a.icon}</div>
                <h3 className="text-white font-semibold mb-1">{a.name}</h3>
                <p className="text-slate-400 text-sm mb-4">{a.desc}</p>
                <button disabled={a.disabled}
                  className={`text-sm px-4 py-2 rounded-lg transition ${a.disabled ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}>
                  {a.cta}
                </button>
              </div>
            ))}
          </div>

          {/* Platform Modules */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
              <h2 className="text-white font-semibold">Platform Modules</h2>
              <input
                value={moduleFilter}
                onChange={e => setModuleFilter(e.target.value)}
                placeholder="Filter modules..."
                className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-blue-500 w-full sm:w-64"
              />
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredModules.map((m, i) => (
                <div key={i} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-white text-sm font-semibold">{m.name}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded-full shrink-0 ${STATUS_COLORS[m.status] || 'bg-slate-700 text-slate-400'}`}>
                      {m.status}
                    </span>
                  </div>
                  <p className="text-slate-500 text-xs leading-relaxed">{m.summary}</p>
                </div>
              ))}
              {filteredModules.length === 0 && (
                <div className="col-span-4 text-center py-8 text-slate-500 text-sm">No modules match your filter.</div>
              )}
            </div>
          </div>

          {/* Environment Stack */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-white font-semibold">Environment Stack</h2>
              <Link to="/organizations" className="text-blue-400 text-xs hover:text-blue-300">Manage Environments →</Link>
            </div>
            {environments.length === 0 ? (
              <div className="text-center text-slate-600 py-6 text-sm">No environments found. <Link to="/organizations" className="text-blue-400">Create via Organizations →</Link></div>
            ) : (
              <div className="space-y-3">
                {environments.slice(0, 5).map((env, i) => (
                  <div key={env.id || i} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-800 border border-slate-700 rounded-xl p-4 hover:border-blue-500/50 transition">
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-semibold">{env.name}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${ENV_STATUS_COLOR[env.status] || 'bg-slate-700 text-slate-400'}`}>
                            {ENV_STATUS_MAP[env.status] || env.status}
                          </span>
                        </div>
                        <div className="text-slate-500 text-xs mt-0.5">{env.region || 'No region'} · {env.type} · {env.runtime}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-xs text-slate-500">Last Deploy</div>
                        <div className="text-white text-sm font-medium">{env.last_deployed_at ? new Date(env.last_deployed_at).toLocaleDateString() : '—'}</div>
                      </div>
                      <Link to={`/environments?id=${env.id}`}
                        className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition shrink-0">
                        Open →
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: '💚', label: 'Health Monitor', desc: 'System health & uptime', path: '/health' },
              { icon: '🚀', label: 'Deployments', desc: 'Track deploy history', path: '/deployments' },
              { icon: '📊', label: 'Analytics', desc: 'Event trends & insights', path: '/team' },
              { icon: '⚙', label: 'Admin Settings', desc: 'Configure the platform', path: '/admin' },
            ].map(l => (
              <Link key={l.label} to={l.path}
                className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-xl p-4 flex items-center gap-3 transition group">
                <span className="text-2xl">{l.icon}</span>
                <div>
                  <div className="text-white text-sm font-medium group-hover:text-blue-400 transition">{l.label}</div>
                  <div className="text-slate-500 text-xs">{l.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}