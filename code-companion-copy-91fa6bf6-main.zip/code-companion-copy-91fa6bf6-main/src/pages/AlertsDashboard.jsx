import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import { Bell, CheckCircle, Clock, AlertTriangle, XCircle, Plus, Filter } from 'lucide-react';

const NAV = [
  { category: 'MONITORING', items: [
    { label: 'Alerts Center', path: '/alerts', icon: '🔔' },
    { label: 'Threats', path: '/threats', icon: '🛡' },
    { label: 'iModel Explorer', path: '/imodels', icon: '⬡' },
  ]},
  { category: 'PLATFORM', items: [
    { label: 'Team', path: '/team', icon: '👥' },
    { label: 'Admin', path: '/admin', icon: '⚙' },
  ]},
];

const SEVERITY_STYLE = {
  Critical: 'bg-red-500/10 text-red-400 border-red-500/20',
  High: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  Medium: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  Low: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  Info: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
};

const STATUS_STYLE = {
  Active: 'bg-red-500/10 text-red-400',
  Acknowledged: 'bg-yellow-500/10 text-yellow-400',
  Resolved: 'bg-green-500/10 text-green-400',
  Pending: 'bg-slate-500/10 text-slate-400',
};

const STATUS_ICON = {
  Active: AlertTriangle,
  Acknowledged: Clock,
  Resolved: CheckCircle,
  Pending: Clock,
};

const SEVERITIES = ['All', 'Critical', 'High', 'Medium', 'Low', 'Info'];
const STATUSES = ['All', 'Active', 'Acknowledged', 'Pending', 'Resolved'];

export default function AlertsDashboard() {
  const { currentUser } = useAuth();
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [severityFilter, setSeverityFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', severity: 'High', source: '', status: 'Active' });
  const [selected, setSelected] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.Alert.list('-created_date', 100).then(data => {
      setAlerts(data);
      setLoading(false);
    });

    const unsub = base44.entities.Alert.subscribe((event) => {
      if (event.type === 'create') setAlerts(prev => [event.data, ...prev]);
      else if (event.type === 'update') setAlerts(prev => prev.map(a => a.id === event.id ? event.data : a));
      else if (event.type === 'delete') setAlerts(prev => prev.filter(a => a.id !== event.id));
    });
    return unsub;
  }, []);

  const filtered = alerts.filter(a =>
    (severityFilter === 'All' || a.severity === severityFilter) &&
    (statusFilter === 'All' || a.status === statusFilter)
  );

  const counts = {
    Critical: alerts.filter(a => a.severity === 'Critical' && a.status === 'Active').length,
    Active: alerts.filter(a => a.status === 'Active').length,
    Resolved: alerts.filter(a => a.status === 'Resolved').length,
    Total: alerts.length,
  };

  const createAlert = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    await base44.entities.Alert.create({ ...form, assigned_to: currentUser?.email });
    setForm({ title: '', description: '', severity: 'High', source: '', status: 'Active' });
    setShowCreate(false);
    setSaving(false);
  };

  const updateStatus = async (alert, status) => {
    await base44.entities.Alert.update(alert.id, { status });
    setSelected(s => s?.id === alert.id ? { ...s, status } : s);
  };

  const deleteAlert = async (id) => {
    await base44.entities.Alert.delete(id);
    if (selected?.id === id) setSelected(null);
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Monitoring" />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-red-400" /> Alerts Center
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">Real-time notifications and incident management</p>
          </div>
          <button onClick={() => setShowCreate(true)}
            className="bg-red-600 hover:bg-red-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> New Alert
          </button>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-6 py-4 border-b border-slate-800">
          {[
            { label: 'Critical Active', value: counts.Critical, color: 'text-red-400' },
            { label: 'Active Alerts', value: counts.Active, color: 'text-orange-400' },
            { label: 'Resolved', value: counts.Resolved, color: 'text-green-400' },
            { label: 'Total Alerts', value: counts.Total, color: 'text-blue-400' },
          ].map(k => (
            <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Alert List */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Filters */}
            <div className="px-6 py-3 border-b border-slate-800 flex flex-wrap gap-2 items-center">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <div className="flex gap-1 flex-wrap">
                {SEVERITIES.map(s => (
                  <button key={s} onClick={() => setSeverityFilter(s)}
                    className={`text-xs px-2 py-0.5 rounded-full transition ${severityFilter === s ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                    {s}
                  </button>
                ))}
              </div>
              <span className="text-slate-700">|</span>
              <div className="flex gap-1 flex-wrap">
                {STATUSES.map(s => (
                  <button key={s} onClick={() => setStatusFilter(s)}
                    className={`text-xs px-2 py-0.5 rounded-full transition ${statusFilter === s ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-800">
              {loading && <div className="text-center text-slate-500 text-sm py-12">Loading alerts...</div>}
              {!loading && filtered.length === 0 && (
                <div className="text-center text-slate-600 text-sm py-12">No alerts found</div>
              )}
              {filtered.map(a => {
                const Icon = STATUS_ICON[a.status] || AlertTriangle;
                return (
                  <button key={a.id} onClick={() => setSelected(a)}
                    className={`w-full text-left px-6 py-4 hover:bg-slate-800/40 transition ${selected?.id === a.id ? 'bg-slate-800/60 border-l-2 border-l-blue-500' : ''}`}>
                    <div className="flex items-start gap-3">
                      <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${a.status === 'Resolved' ? 'text-green-400' : a.status === 'Active' ? 'text-red-400' : 'text-yellow-400'}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-white text-sm font-medium">{a.title}</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded border ${SEVERITY_STYLE[a.severity]}`}>{a.severity}</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded-full ${STATUS_STYLE[a.status]}`}>{a.status}</span>
                        </div>
                        <div className="text-slate-500 text-xs mt-0.5 truncate">{a.source} · {new Date(a.created_date).toLocaleString()}</div>
                        {a.description && <div className="text-slate-400 text-xs mt-1 line-clamp-1">{a.description}</div>}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detail Panel */}
          {selected && (
            <div className="w-80 shrink-0 border-l border-slate-800 flex flex-col bg-slate-900 overflow-y-auto">
              <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <h3 className="text-white text-sm font-semibold">Alert Detail</h3>
                <button onClick={() => setSelected(null)} className="text-slate-500 hover:text-white text-xs">✕</button>
              </div>
              <div className="p-4 space-y-4">
                <div>
                  <div className="flex gap-2 flex-wrap mb-2">
                    <span className={`text-xs px-2 py-0.5 rounded border ${SEVERITY_STYLE[selected.severity]}`}>{selected.severity}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_STYLE[selected.status]}`}>{selected.status}</span>
                  </div>
                  <h2 className="text-white font-bold text-base leading-snug">{selected.title}</h2>
                  <p className="text-slate-500 text-xs mt-1">{selected.source}</p>
                </div>

                {selected.description && (
                  <div>
                    <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">Description</div>
                    <p className="text-slate-300 text-sm leading-relaxed">{selected.description}</p>
                  </div>
                )}

                <div>
                  <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">Created</div>
                  <p className="text-slate-300 text-xs">{new Date(selected.created_date).toLocaleString()}</p>
                </div>

                {selected.assigned_to && (
                  <div>
                    <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">Assigned To</div>
                    <p className="text-slate-300 text-xs">{selected.assigned_to}</p>
                  </div>
                )}

                <div>
                  <div className="text-xs text-slate-500 mb-2 uppercase tracking-wide">Update Status</div>
                  <div className="flex flex-wrap gap-2">
                    {['Active', 'Acknowledged', 'Pending', 'Resolved'].map(s => (
                      <button key={s} onClick={() => updateStatus(selected, s)}
                        className={`text-xs px-2 py-1 rounded-lg transition border ${selected.status === s ? 'border-blue-500 text-blue-400' : 'border-slate-700 text-slate-400 hover:border-slate-600'}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <button onClick={() => deleteAlert(selected.id)}
                  className="w-full mt-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs py-2 rounded-lg transition border border-red-500/20 flex items-center justify-center gap-1.5">
                  <XCircle className="w-3.5 h-3.5" /> Delete Alert
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold">New Alert</h3>
              <button onClick={() => setShowCreate(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Alert title *"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Description"
              rows={3}
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500 resize-none" />
            <input value={form.source} onChange={e => setForm(f => ({ ...f, source: e.target.value }))}
              placeholder="Source (e.g., iModel, Network)"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
            <div className="flex gap-3">
              <select value={form.severity} onChange={e => setForm(f => ({ ...f, severity: e.target.value }))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500">
                {['Critical', 'High', 'Medium', 'Low', 'Info'].map(s => <option key={s}>{s}</option>)}
              </select>
              <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500">
                {['Active', 'Pending', 'Acknowledged'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowCreate(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={createAlert} disabled={saving || !form.title.trim()}
                className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">
                {saving ? 'Creating...' : 'Create Alert'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}