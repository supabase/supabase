import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const NAV = [
  { category: 'CLIENT PORTAL', items: [
    { label: 'My Dashboard', path: '/portal', icon: '🌐' },
    { label: 'Projects', path: '/portal', icon: '📁' },
    { label: 'Deliverables', path: '/portal', icon: '📦' },
    { label: 'Reports', path: '/portal', icon: '📊' },
    { label: 'Support', path: '/portal', icon: '💬' },
  ]},
  { category: 'ACCOUNT', items: [
    { label: 'Billing', path: '/portal', icon: '💳' },
    { label: 'Settings', path: '/portal', icon: '⚙' },
  ]},
];

const PROJECTS = [
  { name: 'Smart City Phase 1', status: 'In Progress', progress: 72, due: 'Jun 2026', manager: 'A. Chen' },
  { name: 'Bridge Renovation BRG-04', status: 'Review', progress: 91, due: 'May 2026', manager: 'M. Torres' },
  { name: 'Water Network Upgrade', status: 'Planning', progress: 18, due: 'Dec 2026', manager: 'S. Patel' },
  { name: 'Highway Expansion HW-12', status: 'Completed', progress: 100, due: 'Mar 2026', manager: 'J. Kim' },
];

const DELIVERABLES = [
  { name: 'Q1 Progress Report', type: 'PDF', project: 'Smart City Phase 1', date: '2026-04-01', size: '2.4 MB' },
  { name: 'Bridge Structural Analysis', type: 'XLSX', project: 'Bridge Renovation', date: '2026-03-28', size: '850 KB' },
  { name: 'As-Built Drawings v3', type: 'DWG', project: 'Highway Expansion', date: '2026-03-15', size: '18.2 MB' },
  { name: 'Environmental Impact Study', type: 'PDF', project: 'Water Network', date: '2026-04-05', size: '5.1 MB' },
];

const STATUS_STYLE = {
  'In Progress': 'bg-blue-500/10 text-blue-400',
  'Review': 'bg-yellow-500/10 text-yellow-400',
  'Planning': 'bg-slate-700 text-slate-400',
  'Completed': 'bg-green-500/10 text-green-400',
};

export default function ClientPortal() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('projects');
  const [projects, setProjects] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [license, setLicense] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Project.list('-created_date', 20),
      base44.entities.Deployment.list('-created_date', 20),
      base44.entities.License.list('-created_date', 1),
    ]).then(([pData, dData, lData]) => {
      setProjects(pData);
      setDeployments(dData);
      setLicense(lData[0] || null);
      setLoading(false);
    });
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Client" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">Client Portal</h1>
          <p className="text-slate-400 text-sm mt-1">Your projects, deliverables, and account overview</p>
        </div>

        <div className="p-6 space-y-6">
          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Projects', value: projects.length, icon: '📁', color: 'text-blue-400' },
              { label: 'Deployments', value: deployments.length, icon: '🚀', color: 'text-teal-400' },
              { label: 'Deployed', value: deployments.filter(d => d.status === 'deployed').length, icon: '✅', color: 'text-green-400' },
              { label: 'License', value: license?.status || 'None', icon: '🔑', color: license?.status === 'active' ? 'text-green-400' : 'text-orange-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 w-fit">
            {['projects', 'deliverables', 'billing'].map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition capitalize ${activeTab === tab ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                {tab}
              </button>
            ))}
          </div>

          {/* Projects Tab */}
          {activeTab === 'projects' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-white font-semibold">Projects</h2>
                <Link to="/organizations" className="text-blue-400 text-xs hover:text-blue-300">Manage →</Link>
              </div>
              {loading && <div className="text-center text-slate-500 py-8">Loading...</div>}
              {!loading && projects.length === 0 && (
                <div className="text-center text-slate-600 py-8 text-sm">
                  No projects yet. <Link to="/organizations" className="text-blue-400">Create via Organizations →</Link>
                </div>
              )}
              <div className="space-y-4">
                {projects.map((p, i) => (
                  <div key={p.id || i} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div>
                        <div className="text-white font-medium">{p.name}</div>
                        <div className="text-slate-500 text-xs">Org: {p.organization_name || p.organization_id} · Stack: {p.tech_stack || '—'}</div>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full w-fit ${STATUS_STYLE[p.status] || 'bg-slate-700 text-slate-400'}`}>{p.status}</span>
                    </div>
                    {p.description && <p className="text-slate-500 text-xs">{p.description}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deliverables Tab */}
          {activeTab === 'deliverables' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Deliverables</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                      <th className="text-left py-2 pr-4">Name</th>
                      <th className="text-left py-2 pr-4">Type</th>
                      <th className="text-left py-2 pr-4">Project</th>
                      <th className="text-left py-2 pr-4">Date</th>
                      <th className="text-left py-2 pr-4">Size</th>
                      <th className="text-left py-2">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {DELIVERABLES.map((d, i) => (
                      <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="py-3 pr-4 text-white text-xs">{d.name}</td>
                        <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-400 text-xs px-2 py-0.5 rounded">{d.type}</span></td>
                        <td className="py-3 pr-4 text-slate-400 text-xs">{d.project}</td>
                        <td className="py-3 pr-4 text-slate-500 text-xs">{d.date}</td>
                        <td className="py-3 pr-4 text-slate-500 text-xs">{d.size}</td>
                        <td className="py-3"><button className="text-xs text-blue-400 hover:text-blue-300">📥 Download</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Billing Tab */}
          {activeTab === 'billing' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">License & Billing</h2>
              {!license ? (
                <div className="text-center text-slate-600 py-8 text-sm">
                  No license found. <Link to="/licenses" className="text-blue-400">Activate a license →</Link>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid sm:grid-cols-3 gap-4">
                    {[
                      { label: 'Plan', value: license.plan, color: 'text-blue-400' },
                      { label: 'Status', value: license.status, color: license.status === 'active' ? 'text-green-400' : 'text-red-400' },
                      { label: 'Expires', value: license.expires_at ? new Date(license.expires_at).toLocaleDateString() : 'Never', color: 'text-white' },
                    ].map(b => (
                      <div key={b.label} className="bg-slate-800 rounded-xl p-4">
                        <div className="text-xs text-slate-500 mb-1">{b.label}</div>
                        <div className={`text-lg font-bold capitalize ${b.color}`}>{b.value}</div>
                      </div>
                    ))}
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between text-xs text-slate-400 mb-1"><span>Deployments</span><span>{license.deployments_used || 0} / {license.deployment_quota || 100}</span></div>
                      <div className="w-full bg-slate-700 rounded-full h-2"><div className="bg-blue-500 h-2 rounded-full" style={{ width: `${Math.min(100, ((license.deployments_used || 0) / (license.deployment_quota || 100)) * 100)}%` }} /></div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-slate-400 mb-1"><span>Seats</span><span>{license.seats_used || 0} / {license.seat_limit || 5}</span></div>
                      <div className="w-full bg-slate-700 rounded-full h-2"><div className="bg-purple-500 h-2 rounded-full" style={{ width: `${Math.min(100, ((license.seats_used || 0) / (license.seat_limit || 5)) * 100)}%` }} /></div>
                    </div>
                  </div>
                  <div className="text-slate-500 text-xs">Key fingerprint: <span className="font-mono">{license.key_fingerprint}</span></div>
                  <Link to="/licenses" className="block text-center bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm py-2 rounded-lg transition">Manage License →</Link>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}