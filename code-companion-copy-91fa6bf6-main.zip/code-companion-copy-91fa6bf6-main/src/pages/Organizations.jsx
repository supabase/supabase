import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import { Plus, Building2, Users, Layers, ChevronRight, Trash2 } from 'lucide-react';

const NAV = [
  { category: 'HIERARCHY', items: [
    { label: 'Organizations', path: '/organizations', icon: '🏢' },
    { label: 'Projects', path: '/projects', icon: '📁' },
    { label: 'Environments', path: '/environments', icon: '🌍' },
    { label: 'Deployments', path: '/deployments', icon: '🚀' },
  ]},
  { category: 'PLATFORM', items: [
    { label: 'Licenses', path: '/licenses', icon: '🔑' },
    { label: 'Admin', path: '/admin', icon: '⚙' },
  ]},
];

const PLAN_STYLE = {
  free: 'bg-slate-700 text-slate-300',
  starter: 'bg-blue-500/10 text-blue-400',
  professional: 'bg-purple-500/10 text-purple-400',
  enterprise: 'bg-yellow-500/10 text-yellow-400',
};

const STATUS_STYLE = {
  active: 'bg-green-500/10 text-green-400',
  suspended: 'bg-red-500/10 text-red-400',
  trial: 'bg-orange-500/10 text-orange-400',
  cancelled: 'bg-slate-700 text-slate-500',
};

export default function Organizations() {
  const { currentUser } = useAuth();
  const [orgs, setOrgs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', slug: '', plan: 'starter', owner_email: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.Organization.list('-created_date', 100).then(data => {
      setOrgs(data);
      setLoading(false);
    });
    const unsub = base44.entities.Organization.subscribe(event => {
      if (event.type === 'create') setOrgs(p => [event.data, ...p]);
      else if (event.type === 'update') setOrgs(p => p.map(o => o.id === event.id ? event.data : o));
      else if (event.type === 'delete') setOrgs(p => p.filter(o => o.id !== event.id));
    });
    return unsub;
  }, []);

  const createOrg = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    await base44.entities.Organization.create({
      ...form,
      slug: form.slug || form.name.toLowerCase().replace(/\s+/g, '-'),
      owner_email: form.owner_email || currentUser?.email,
    });
    setForm({ name: '', slug: '', plan: 'starter', owner_email: '' });
    setShowCreate(false);
    setSaving(false);
  };

  const deleteOrg = async (id) => {
    await base44.entities.Organization.delete(id);
  };

  const counts = {
    total: orgs.length,
    active: orgs.filter(o => o.status === 'active').length,
    trial: orgs.filter(o => o.status === 'trial').length,
    enterprise: orgs.filter(o => o.plan === 'enterprise').length,
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Platform Admin" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-purple-400" /> Organizations
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">Tenant management — top of the hierarchy</p>
          </div>
          <button onClick={() => setShowCreate(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> New Org
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-6 py-4 border-b border-slate-800">
          {[
            { label: 'Total Orgs', value: counts.total, color: 'text-white' },
            { label: 'Active', value: counts.active, color: 'text-green-400' },
            { label: 'Trial', value: counts.trial, color: 'text-orange-400' },
            { label: 'Enterprise', value: counts.enterprise, color: 'text-yellow-400' },
          ].map(k => (
            <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {loading && <div className="text-center text-slate-500 py-12">Loading organizations...</div>}
          {!loading && orgs.length === 0 && (
            <div className="text-center text-slate-600 py-16">
              <Building2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <div className="text-sm">No organizations yet.</div>
              <button onClick={() => setShowCreate(true)} className="mt-3 text-purple-400 text-xs hover:text-purple-300">+ Create first org</button>
            </div>
          )}
          <div className="space-y-3">
            {orgs.map(org => (
              <div key={org.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center shrink-0">
                  <Building2 className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-white font-semibold text-sm">{org.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${PLAN_STYLE[org.plan] || 'bg-slate-700 text-slate-300'}`}>{org.plan}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${STATUS_STYLE[org.status] || 'bg-slate-700 text-slate-400'}`}>{org.status || 'active'}</span>
                  </div>
                  <div className="flex gap-4 mt-1 text-xs text-slate-500">
                    <span>/{org.slug}</span>
                    <span>{org.owner_email}</span>
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {org.max_seats || 5} seats</span>
                    <span className="flex items-center gap-1"><Layers className="w-3 h-3" /> {org.max_projects || 5} projects</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Link to={`/projects?org=${org.id}`}
                    className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                    Projects <ChevronRight className="w-3 h-3" />
                  </Link>
                  <button onClick={() => deleteOrg(org.id)}
                    className="bg-red-500/10 hover:bg-red-500/20 text-red-400 p-1.5 rounded-lg transition">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold flex items-center gap-2"><Building2 className="w-4 h-4 text-purple-400" /> New Organization</h3>
              <button onClick={() => setShowCreate(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="Organization name *"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500" />
            <input value={form.slug} onChange={e => setForm(f => ({ ...f, slug: e.target.value }))}
              placeholder="Slug (auto-generated if empty)"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500" />
            <input value={form.owner_email} onChange={e => setForm(f => ({ ...f, owner_email: e.target.value }))}
              placeholder={`Owner email (default: ${currentUser?.email})`}
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500" />
            <select value={form.plan} onChange={e => setForm(f => ({ ...f, plan: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500">
              {['free', 'starter', 'professional', 'enterprise'].map(p => <option key={p}>{p}</option>)}
            </select>
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowCreate(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={createOrg} disabled={saving || !form.name.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">
                {saving ? 'Creating...' : 'Create Org'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}