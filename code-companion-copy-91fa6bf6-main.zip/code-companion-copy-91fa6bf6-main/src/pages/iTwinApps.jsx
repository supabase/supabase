import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import { Plus, Upload, Globe, CheckCircle, Clock, AlertTriangle, Trash2, ExternalLink } from 'lucide-react';

const NAV = [
  { category: 'ITWIN APPS', items: [
    { label: 'My Apps', path: '/itwin-apps', icon: '📦' },
    { label: 'Deployments', path: '/deployments', icon: '🚀' },
    { label: 'iModel Explorer', path: '/imodels', icon: '⬡' },
    { label: 'Integrations', path: '/integrations', icon: '🔌' },
  ]},
  { category: 'PLATFORM', items: [
    { label: 'Team', path: '/team', icon: '👥' },
    { label: 'Admin', path: '/admin', icon: '⚙' },
  ]},
];

const INTEGRATIONS = [
  { name: 'Bentley iTwin Platform', icon: '⬡' },
  { name: 'GitHub Actions CI/CD', icon: '🐙' },
  { name: 'Azure DevOps', icon: '☁' },
  { name: 'Slack Notifications', icon: '💬' },
  { name: 'Datadog Monitoring', icon: '📊' },
  { name: 'Okta SSO', icon: '🔐' },
];

const STATUS_STYLE = {
  Deployed: 'bg-green-500/10 text-green-400 border-green-500/20',
  Building: 'bg-blue-500/10 text-blue-400 border-blue-500/20 animate-pulse',
  Failed: 'bg-red-500/10 text-red-400 border-red-500/20',
  Draft: 'bg-slate-700 text-slate-400 border-slate-600',
  Archived: 'bg-slate-700 text-slate-500 border-slate-700',
};

const STATUS_ICON = { Deployed: CheckCircle, Building: Clock, Failed: AlertTriangle, Draft: Clock, Archived: Clock };

const ENV_STYLE = {
  Production: 'bg-purple-500/10 text-purple-400',
  Staging: 'bg-yellow-500/10 text-yellow-400',
  Development: 'bg-slate-700 text-slate-400',
};

export default function ITwinApps() {
  const { currentUser } = useAuth();
  const [apps, setApps] = useState([]);
  const [integrationConnections, setIntegrationConnections] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('apps');
  const [showCreate, setShowCreate] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'Viewer', imodel_name: '', environment: 'Development' });
  const [importUrl, setImportUrl] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.iTwinApp.list('-created_date', 100),
      base44.entities.IntegrationConnection.list('-created_date', 50),
      base44.entities.Deployment.list('-created_date', 100),
    ]).then(([appsData, intgData, depsData]) => {
      setApps(appsData);
      setIntegrationConnections(intgData);
      setDeployments(depsData);
      setLoading(false);
    });

    const unsubApps = base44.entities.iTwinApp.subscribe(event => {
      if (event.type === 'create') setApps(p => [event.data, ...p]);
      else if (event.type === 'update') setApps(p => p.map(a => a.id === event.id ? event.data : a));
      else if (event.type === 'delete') setApps(p => p.filter(a => a.id !== event.id));
    });
    const unsubDeps = base44.entities.Deployment.subscribe(event => {
      if (event.type === 'create') setDeployments(p => [event.data, ...p]);
      else if (event.type === 'update') setDeployments(p => p.map(d => d.id === event.id ? event.data : d));
    });

    return () => { unsubApps(); unsubDeps(); };
  }, []);

  const createApp = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    await base44.entities.iTwinApp.create({
      name: form.name,
      type: form.type,
      status: 'Draft',
      environment: form.environment,
      version: 'v0.1.0',
      imodel_name: form.imodel_name,
      last_deployed_by: currentUser?.email,
      deploy_count: 0,
    });
    setForm({ name: '', type: 'Viewer', imodel_name: '', environment: 'Development' });
    setShowCreate(false);
    setSaving(false);
  };

  const importApp = async () => {
    if (!importUrl.trim()) return;
    setSaving(true);
    const appName = importUrl.split('/').filter(Boolean).pop() || 'Imported App';
    await base44.entities.iTwinApp.create({
      name: appName,
      type: 'Imported',
      status: 'Building',
      environment: 'Development',
      version: 'v1.0.0',
      repo_url: importUrl,
      imodel_name: 'Pending',
      last_deployed_by: currentUser?.email,
      last_deployed_at: new Date().toISOString(),
      deploy_count: 0,
    });
    setImportUrl('');
    setShowImport(false);
    setSaving(false);
  };

  const deploy = async (app) => {
    // Update app status
    await base44.entities.iTwinApp.update(app.id, {
      status: 'Building',
      last_deployed_at: new Date().toISOString(),
      last_deployed_by: currentUser?.email,
      deploy_count: (app.deploy_count || 0) + 1,
    });
    // Create deployment record
    await base44.entities.Deployment.create({
      app_name: app.name,
      app_id: app.id,
      environment_name: app.environment,
      environment_type: app.environment,
      version: app.version || 'v0.1.0',
      status: 'queued',
      triggered_by: currentUser?.email,
      trigger_source: 'manual',
      started_at: new Date().toISOString(),
    });
  };

  const deleteApp = async (id) => {
    await base44.entities.iTwinApp.delete(id);
  };

  const toggleIntegration = async (intg) => {
    const existing = integrationConnections.find(c => c.integration_name === intg.name);
    if (existing) {
      await base44.entities.IntegrationConnection.update(existing.id, {
        status: existing.status === 'connected' ? 'disconnected' : 'connected',
        last_used_at: new Date().toISOString(),
      });
      setIntegrationConnections(p => p.map(c => c.id === existing.id
        ? { ...c, status: c.status === 'connected' ? 'disconnected' : 'connected' } : c));
    } else {
      const created = await base44.entities.IntegrationConnection.create({
        integration_name: intg.name,
        integration_type: 'cicd',
        status: 'connected',
        connected_by: currentUser?.email,
        last_used_at: new Date().toISOString(),
      });
      setIntegrationConnections(p => [...p, created]);
    }
  };

  const getIntegrationStatus = (name) => {
    const conn = integrationConnections.find(c => c.integration_name === name);
    return conn?.status || 'disconnected';
  };

  const counts = {
    total: apps.length,
    deployed: apps.filter(a => a.status === 'Deployed').length,
    building: apps.filter(a => a.status === 'Building').length,
    failed: apps.filter(a => a.status === 'Failed').length,
  };

  const appDeployments = (appId) => deployments.filter(d => d.app_id === appId);

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Developer" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="text-purple-400">⬡</span> iTwin App Manager
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">Create, import, deploy and integrate your iTwin applications</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowImport(true)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" /> Import
            </button>
            <button onClick={() => setShowCreate(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5" /> New App
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-6 py-4 border-b border-slate-800">
          {[
            { label: 'Total Apps', value: counts.total, color: 'text-white' },
            { label: 'Deployed', value: counts.deployed, color: 'text-green-400' },
            { label: 'Building', value: counts.building, color: 'text-blue-400' },
            { label: 'Failed', value: counts.failed, color: 'text-red-400' },
          ].map(k => (
            <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-1 px-6 py-3 border-b border-slate-800">
          {['apps', 'integrations', 'deployments'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium transition capitalize ${tab === t ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}>
              {t}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {loading && <div className="text-center text-slate-500 py-12">Loading apps...</div>}

          {tab === 'apps' && !loading && (
            <div className="space-y-3">
              {apps.map(app => {
                const Icon = STATUS_ICON[app.status] || Clock;
                return (
                  <div key={app.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-white font-semibold text-sm">{app.name}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded border ${STATUS_STYLE[app.status]} flex items-center gap-1`}>
                          <Icon className="w-3 h-3" /> {app.status}
                        </span>
                        <span className={`text-xs px-1.5 py-0.5 rounded-full ${ENV_STYLE[app.environment]}`}>{app.environment}</span>
                        <span className="text-xs text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded">{app.type}</span>
                      </div>
                      <div className="flex gap-4 mt-1.5 text-xs text-slate-500 flex-wrap">
                        <span>iModel: <span className="text-slate-400">{app.imodel_name || '—'}</span></span>
                        <span>Version: <span className="text-slate-400">{app.version}</span></span>
                        <span>Deploys: <span className="text-slate-400">{app.deploy_count || 0}</span></span>
                        {app.last_deployed_at && <span>Last: <span className="text-slate-400">{new Date(app.last_deployed_at).toLocaleString()}</span></span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {app.deploy_url && (
                        <a href={app.deploy_url} target="_blank" rel="noreferrer"
                          className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                          <ExternalLink className="w-3 h-3" /> Open
                        </a>
                      )}
                      {app.status !== 'Building' && (
                        <button onClick={() => deploy(app)}
                          className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1">
                          <Globe className="w-3 h-3" /> Deploy
                        </button>
                      )}
                      <button onClick={() => deleteApp(app.id)}
                        className="bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs px-2 py-1.5 rounded-lg transition">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
              {apps.length === 0 && (
                <div className="text-center text-slate-600 py-16">No apps yet. Create or import one to get started.</div>
              )}
            </div>
          )}

          {tab === 'integrations' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {INTEGRATIONS.map(intg => {
                const status = getIntegrationStatus(intg.name);
                return (
                  <div key={intg.name} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{intg.icon}</span>
                      <div>
                        <div className="text-white text-sm font-medium">{intg.name}</div>
                        <div className={`text-xs mt-0.5 ${status === 'connected' ? 'text-green-400' : 'text-slate-500'}`}>
                          {status}
                        </div>
                      </div>
                    </div>
                    <button onClick={() => toggleIntegration(intg)}
                      className={`text-xs px-3 py-1.5 rounded-lg transition ${status === 'connected' ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : 'bg-purple-600 text-white hover:bg-purple-700'}`}>
                      {status === 'connected' ? 'Disconnect' : 'Connect'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'deployments' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left px-4 py-3">App</th>
                    <th className="text-left px-4 py-3">Version</th>
                    <th className="text-left px-4 py-3">Environment</th>
                    <th className="text-left px-4 py-3">Status</th>
                    <th className="text-left px-4 py-3">By</th>
                    <th className="text-left px-4 py-3">When</th>
                  </tr>
                </thead>
                <tbody>
                  {deployments.slice(0, 50).map(dep => {
                    const Icon = STATUS_ICON[dep.status] || Clock;
                    return (
                      <tr key={dep.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="px-4 py-3 text-white text-xs font-medium">{dep.app_name}</td>
                        <td className="px-4 py-3 text-slate-400 text-xs">{dep.version}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-1.5 py-0.5 rounded-full ${ENV_STYLE[dep.environment_type] || 'bg-slate-700 text-slate-400'}`}>{dep.environment_name || dep.environment_type}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-1.5 py-0.5 rounded border flex items-center gap-1 w-fit ${STATUS_STYLE[dep.status] || 'bg-slate-700 text-slate-400 border-slate-600'}`}>
                            <Icon className="w-3 h-3" /> {dep.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-500 text-xs">{dep.triggered_by}</td>
                        <td className="px-4 py-3 text-slate-500 text-xs">{new Date(dep.created_date).toLocaleString()}</td>
                      </tr>
                    );
                  })}
                  {deployments.length === 0 && (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-600">No deployments yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold flex items-center gap-2"><Plus className="w-4 h-4 text-purple-400" /> New iTwin App</h3>
              <button onClick={() => setShowCreate(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="App name *"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500" />
            <input value={form.imodel_name} onChange={e => setForm(f => ({ ...f, imodel_name: e.target.value }))}
              placeholder="iModel name (optional)"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500" />
            <div className="flex gap-3">
              <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500">
                {['Viewer', 'Inspector', 'Dashboard', 'Map', 'Analyzer', 'Custom'].map(t => <option key={t}>{t}</option>)}
              </select>
              <select value={form.environment} onChange={e => setForm(f => ({ ...f, environment: e.target.value }))}
                className="flex-1 bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500">
                {['Development', 'Staging', 'Production'].map(e => <option key={e}>{e}</option>)}
              </select>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowCreate(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={createApp} disabled={saving || !form.name.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">
                {saving ? 'Creating...' : 'Create App'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showImport && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold flex items-center gap-2"><Upload className="w-4 h-4 text-blue-400" /> Import App</h3>
              <button onClick={() => setShowImport(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <p className="text-slate-400 text-xs">Import an existing iTwin app from a GitHub repository or Bentley iTwin registry URL.</p>
            <input value={importUrl} onChange={e => setImportUrl(e.target.value)}
              placeholder="https://github.com/org/repo or registry URL"
              className="w-full bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
            <div className="flex gap-2 pt-1">
              <button onClick={() => setShowImport(false)} className="flex-1 bg-slate-800 text-slate-300 text-sm py-2 rounded-lg hover:bg-slate-700 transition">Cancel</button>
              <button onClick={importApp} disabled={saving || !importUrl.trim()}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-sm py-2 rounded-lg transition">
                {saving ? 'Importing...' : 'Import'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}