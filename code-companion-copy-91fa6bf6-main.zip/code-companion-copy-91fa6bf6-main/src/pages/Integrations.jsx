import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const NAV = [
  { category: 'INTEGRATIONS', items: [
    { label: 'All Integrations', path: '/integrations', icon: '🔌' },
    { label: 'Connected', path: '/integrations', icon: '✅' },
    { label: 'Webhooks', path: '/integrations', icon: '🪝' },
    { label: 'API Keys', path: '/integrations', icon: '🔑' },
  ]},
  { category: 'DEVELOPER', items: [
    { label: 'API Reference', path: '/integrations', icon: '📖' },
    { label: 'SDK Downloads', path: '/integrations', icon: '⬇' },
  ]},
];

const INTEGRATIONS = [
  { name: 'Bentley iTwin Platform', category: 'Core', icon: '⬡', status: 'Connected', desc: 'Core digital twin data access and iModel sync.', type: 'Platform' },
  { name: 'Slack', category: 'Notifications', icon: '💬', status: 'Connected', desc: 'Alert delivery and team notifications via Slack channels.', type: 'Communication' },
  { name: 'PagerDuty', category: 'Incidents', icon: '🚨', status: 'Connected', desc: 'Critical incident escalation and on-call routing.', type: 'Operations' },
  { name: 'Salesforce', category: 'CRM', icon: '☁', status: 'Available', desc: 'Sync client and lead data with Salesforce CRM.', type: 'CRM' },
  { name: 'HubSpot', category: 'Marketing', icon: '🎯', status: 'Available', desc: 'Marketing automation and lead management.', type: 'Marketing' },
  { name: 'GitHub', category: 'Dev', icon: '🐙', status: 'Connected', desc: 'Track deployments and code changes from your repos.', type: 'Development' },
  { name: 'Stripe', category: 'Payments', icon: '💳', status: 'Available', desc: 'Billing, subscriptions, and invoice automation.', type: 'Finance' },
  { name: 'Datadog', category: 'Observability', icon: '📊', status: 'Available', desc: 'APM, metrics, logs, and tracing at scale.', type: 'Monitoring' },
  { name: 'Sentry', category: 'Errors', icon: '🐛', status: 'Available', desc: 'Real-time error tracking and crash reporting.', type: 'Monitoring' },
  { name: 'Jira', category: 'Project', icon: '📋', status: 'Available', desc: 'Issue tracking and agile project management.', type: 'Development' },
  { name: 'SendGrid', category: 'Email', icon: '📧', status: 'Connected', desc: 'Transactional email delivery and templates.', type: 'Communication' },
  { name: 'Zapier', category: 'Automation', icon: '⚡', status: 'Available', desc: 'No-code automation to connect any tool.', type: 'Automation' },
];

const STATUS_STYLE = {
  Connected: 'bg-green-500/10 text-green-400',
  Available: 'bg-slate-700 text-slate-400',
  Beta: 'bg-yellow-500/10 text-yellow-400',
};

export default function Integrations() {
  const { currentUser } = useAuth();
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [connections, setConnections] = useState([]);
  const [webhookCount, setWebhookCount] = useState(0);

  useEffect(() => {
    base44.entities.IntegrationConnection.list('-created_date', 100).then(setConnections);
    base44.entities.WebhookDelivery.list('-created_date', 1).then(d => setWebhookCount(d.length ? 'Live' : '0'));
    const unsub = base44.entities.IntegrationConnection.subscribe(e => {
      if (e.type === 'create') setConnections(p => [e.data, ...p]);
      else if (e.type === 'update') setConnections(p => p.map(c => c.id === e.id ? e.data : c));
      else if (e.type === 'delete') setConnections(p => p.filter(c => c.id !== e.id));
    });
    return unsub;
  }, []);

  const getStatus = (name) => {
    const conn = connections.find(c => c.integration_name === name);
    return conn ? { status: conn.status, id: conn.id } : { status: 'Available', id: null };
  };

  const toggle = async (intg) => {
    const { status, id } = getStatus(intg.name);
    if (id) {
      const newStatus = status === 'connected' ? 'disconnected' : 'connected';
      await base44.entities.IntegrationConnection.update(id, { status: newStatus, last_used_at: new Date().toISOString() });
    } else {
      await base44.entities.IntegrationConnection.create({
        integration_name: intg.name,
        integration_type: intg.type?.toLowerCase() || 'cicd',
        status: 'connected',
        connected_by: currentUser?.email,
        last_used_at: new Date().toISOString(),
      });
    }
  };

  const types = ['All', ...new Set(INTEGRATIONS.map(i => i.type))];
  const filtered = INTEGRATIONS.filter(i =>
    (filter === 'All' || i.type === filter) &&
    i.name.toLowerCase().includes(search.toLowerCase())
  );

  const connected = connections.filter(c => c.status === 'connected').length;

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Developer" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-2xl font-bold text-white">🔌 Integrations</h1>
          <p className="text-slate-400 text-sm mt-1">Connect third-party services, manage API keys, and configure webhooks</p>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Connected', value: connected, icon: '✅', color: 'text-green-400' },
              { label: 'Available', value: INTEGRATIONS.length - connected, icon: '🔌', color: 'text-slate-400' },
              { label: 'Total Catalog', value: INTEGRATIONS.length, icon: '⚡', color: 'text-blue-400' },
              { label: 'Webhook Log', value: webhookCount, icon: '🪝', color: 'text-purple-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search integrations..."
              className="bg-slate-900 border border-slate-800 text-white text-sm rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500 w-full sm:w-72" />
            <div className="flex gap-1 flex-wrap">
              {types.map(t => (
                <button key={t} onClick={() => setFilter(t)}
                  className={`text-xs px-3 py-1.5 rounded-lg transition ${filter === t ? 'bg-blue-600 text-white' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((int, i) => {
              const { status } = getStatus(int.name);
              const isConnected = status === 'connected';
              return (
                <div key={i} className="bg-slate-900 border border-slate-800 hover:border-blue-500/40 rounded-xl p-5 transition">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{int.icon}</span>
                      <div>
                        <div className="text-white font-medium text-sm">{int.name}</div>
                        <span className="text-xs text-slate-600">{int.type}</span>
                      </div>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full shrink-0 ${isConnected ? STATUS_STYLE.Connected : STATUS_STYLE.Available}`}>
                      {isConnected ? 'Connected' : 'Available'}
                    </span>
                  </div>
                  <p className="text-slate-500 text-xs leading-relaxed mb-3">{int.desc}</p>
                  {int.requiresBackend && (
                    <p className="text-yellow-600 text-xs mb-2">⚠ Full OAuth requires external backend config</p>
                  )}
                  <button onClick={() => toggle(int)}
                    className={`w-full text-xs py-1.5 rounded-lg transition ${isConnected ? 'bg-slate-800 hover:bg-slate-700 text-slate-300' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}>
                    {isConnected ? 'Disconnect' : 'Connect'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}