import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useRoleGuard } from '@/hooks/useRoleGuard';

const NAV = [
  { category: 'SUPER ADMIN', items: [
    { label: 'Overview', path: '/superadmin', icon: '👑' },
    { label: 'Tenant Management', path: '/superadmin', icon: '🏢' },
    { label: 'Global Settings', path: '/superadmin', icon: '⚙' },
    { label: 'Billing & Subscriptions', path: '/superadmin', icon: '💳' },
    { label: 'Audit Logs', path: '/superadmin', icon: '📋' },
    { label: 'Feature Flags', path: '/superadmin', icon: '🚩' },
  ]},
  { category: 'SYSTEM', items: [
    { label: 'Infrastructure', path: '/superadmin', icon: '🏗️' },
    { label: 'Security Center', path: '/threats', icon: '🛡' },
    { label: 'Compliance', path: '/compliance', icon: '⚖' },
  ]},
];

const TENANTS = [
  { name: 'Bentley Systems', plan: 'Enterprise', users: 342, status: 'Active', mrr: '$18,400', since: 'Jan 2024' },
  { name: 'Infrastructure Corp', plan: 'Business', users: 89, status: 'Active', mrr: '$4,200', since: 'Mar 2024' },
  { name: 'Civil Works Ltd', plan: 'Starter', users: 12, status: 'Trial', mrr: '$0', since: 'Apr 2026' },
  { name: 'Smart City Ventures', plan: 'Business', users: 156, status: 'Active', mrr: '$7,800', since: 'Jun 2024' },
  { name: 'Global Roads Inc', plan: 'Enterprise', users: 210, status: 'Active', mrr: '$14,200', since: 'Sep 2024' },
];

const FEATURE_FLAGS = [
  { name: 'iTwin 3D Viewer', enabled: true, desc: 'Real-time 3D model rendering in explorer' },
  { name: 'AI Recommendations', enabled: true, desc: 'LLM-powered model insights' },
  { name: 'Marketplace', enabled: false, desc: 'Partner integrations marketplace' },
  { name: 'Advanced Analytics', enabled: true, desc: 'Deep reporting and trend analysis' },
  { name: 'Multi-Region Deploy', enabled: false, desc: 'Cross-region infrastructure support' },
];

export default function SuperAdminDashboard() {
  const { isAdmin } = useRoleGuard('admin', '/');
  const { currentUser } = useAuth();
  const [flags, setFlags] = useState([]);
  const [orgs, setOrgs] = useState([]);
  const [loadingFlags, setLoadingFlags] = useState(true);
  const [loadingOrgs, setLoadingOrgs] = useState(true);

  useEffect(() => {
    base44.entities.FeatureFlag.list('name', 50).then(data => {
      if (data.length === 0) {
        // Seed default flags if none exist
        Promise.all(FEATURE_FLAGS.map(f =>
          base44.entities.FeatureFlag.create({ name: f.name, key: f.name.toLowerCase().replace(/\s+/g, '_'), enabled: f.enabled, description: f.desc, scope: 'global' })
        )).then(created => setFlags(created));
      } else {
        setFlags(data);
      }
      setLoadingFlags(false);
    });
    base44.entities.Organization.list('-created_date', 50).then(data => {
      setOrgs(data);
      setLoadingOrgs(false);
    });
    const unsub = base44.entities.FeatureFlag.subscribe(e => {
      if (e.type === 'update') setFlags(p => p.map(f => f.id === e.id ? e.data : f));
      if (e.type === 'create') setFlags(p => [...p, e.data]);
    });
    return unsub;
  }, []);

  const toggleFlag = async (flag) => {
    const updated = await base44.entities.FeatureFlag.update(flag.id, {
      enabled: !flag.enabled,
      last_changed_by: currentUser?.email,
    });
    setFlags(p => p.map(f => f.id === flag.id ? updated : f));
  };

  const suspendOrg = async (org) => {
    await base44.entities.Organization.update(org.id, { status: 'suspended' });
    setOrgs(p => p.map(o => o.id === org.id ? { ...o, status: 'suspended' } : o));
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Super Admin" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">👑 Super Admin</h1>
            <p className="text-slate-400 text-sm mt-1">Global platform control — tenants, billing, infrastructure, feature flags</p>
          </div>
          <div className="flex gap-2">
            <Link to="/admin" className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">Admin Panel →</Link>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Total Orgs', value: orgs.length, icon: '🏢', color: 'text-blue-400' },
              { label: 'Active', value: orgs.filter(o => o.status === 'active' || !o.status).length, icon: '✅', color: 'text-green-400' },
              { label: 'Trial', value: orgs.filter(o => o.status === 'trial').length, icon: '⏳', color: 'text-orange-400' },
              { label: 'Feature Flags', value: flags.length, icon: '🚩', color: 'text-purple-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Tenant Management */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white font-semibold">Tenant Management</h2>
              <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ Add Tenant</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Organization</th>
                    <th className="text-left py-2 pr-4">Plan</th>
                    <th className="text-left py-2 pr-4">Users</th>
                    <th className="text-left py-2 pr-4">MRR</th>
                    <th className="text-left py-2 pr-4">Status</th>
                    <th className="text-left py-2 pr-4">Since</th>
                    <th className="text-left py-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loadingOrgs && <tr><td colSpan={7} className="text-center text-slate-500 py-8">Loading...</td></tr>}
                  {!loadingOrgs && orgs.length === 0 && <tr><td colSpan={7} className="text-center text-slate-600 py-8">No organizations yet. <Link to="/organizations" className="text-blue-400">Create one →</Link></td></tr>}
                  {orgs.map((t, i) => (
                    <tr key={t.id || i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white font-medium text-xs">{t.name}</td>
                      <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded">{t.plan}</span></td>
                      <td className="py-3 pr-4 text-slate-400 text-xs">{t.max_seats || 5}</td>
                      <td className="py-3 pr-4 text-slate-500 text-xs">—</td>
                      <td className="py-3 pr-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${(t.status === 'active' || !t.status) ? 'bg-green-500/10 text-green-400' : t.status === 'trial' ? 'bg-yellow-500/10 text-yellow-400' : 'bg-red-500/10 text-red-400'}`}>{t.status || 'active'}</span>
                      </td>
                      <td className="py-3 pr-4 text-slate-500 text-xs">{new Date(t.created_date).toLocaleDateString()}</td>
                      <td className="py-3">
                        <div className="flex gap-2">
                          <Link to="/organizations" className="text-xs text-blue-400 hover:text-blue-300">Manage</Link>
                          {t.status !== 'suspended' && (
                            <button onClick={() => suspendOrg(t)} className="text-xs text-red-400 hover:text-red-300">Suspend</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Feature Flags */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">🚩 Feature Flags</h2>
            <div className="space-y-3">
              {loadingFlags && <div className="text-slate-500 text-sm">Loading flags...</div>}
              {flags.map((f) => (
                <div key={f.id} className="flex items-center justify-between p-3 bg-slate-800 rounded-xl">
                  <div>
                    <div className="text-white text-sm font-medium">{f.name}</div>
                    <div className="text-slate-500 text-xs">{f.description}</div>
                    {f.last_changed_by && <div className="text-slate-700 text-xs mt-0.5">Last changed by: {f.last_changed_by}</div>}
                  </div>
                  <button onClick={() => toggleFlag(f)}
                    className={`w-11 h-6 rounded-full transition-all relative ${f.enabled ? 'bg-blue-600' : 'bg-slate-700'}`}>
                    <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${f.enabled ? 'left-5' : 'left-0.5'}`} />
                  </button>
                </div>
              ))}
              </div>
          </div>

          {/* Quick Links */}
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { icon: '🛡', label: 'Security Center', path: '/threats', desc: 'Threats & monitoring' },
              { icon: '⚖', label: 'Compliance', path: '/compliance', desc: 'Regulatory review' },
              { icon: '📊', label: 'Analytics', path: '/marketing', desc: 'Platform-wide insights' },
            ].map(l => (
              <Link key={l.label} to={l.path}
                className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-xl p-5 flex items-center gap-4 transition group">
                <span className="text-3xl">{l.icon}</span>
                <div>
                  <div className="text-white font-medium group-hover:text-blue-400 transition">{l.label}</div>
                  <div className="text-slate-500 text-xs">{l.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}