import { useState } from 'react';
import Sidebar from '@/components/Sidebar';

const NAV = [
  { category: 'AUTOMATION', items: [
    { label: 'Workflows', path: '/automation', icon: '⚙' },
    { label: 'Triggers', path: '/automation', icon: '⚡' },
    { label: 'Schedules', path: '/automation', icon: '🕐' },
    { label: 'Run History', path: '/automation', icon: '📋' },
  ]},
  { category: 'BUILDER', items: [
    { label: 'Workflow Builder', path: '/automation', icon: '🔧' },
    { label: 'Templates', path: '/automation', icon: '📄' },
  ]},
];

const WORKFLOWS = [
  { name: 'iModel Sync Watcher', trigger: 'Webhook', status: 'Active', lastRun: '2m ago', runs: 4291, success: '99.8%' },
  { name: 'Alert → Slack Dispatch', trigger: 'Event Rule', status: 'Active', lastRun: '8m ago', runs: 1847, success: '100%' },
  { name: 'Weekly Performance Report', trigger: 'Schedule', status: 'Active', lastRun: '2d ago', runs: 48, success: '100%' },
  { name: 'New Tenant Onboarding', trigger: 'User Created', status: 'Active', lastRun: '1d ago', runs: 47, success: '97.8%' },
  { name: 'Vulnerability Scan', trigger: 'Schedule', status: 'Paused', lastRun: '7d ago', runs: 12, success: '91.7%' },
  { name: 'Client Invoice Generator', trigger: 'Monthly', status: 'Active', lastRun: '7d ago', runs: 36, success: '100%' },
];

const HISTORY = [
  { workflow: 'iModel Sync Watcher', status: 'success', duration: '0.4s', time: '2m ago' },
  { workflow: 'Alert → Slack Dispatch', status: 'success', duration: '1.2s', time: '8m ago' },
  { workflow: 'iModel Sync Watcher', status: 'success', duration: '0.3s', time: '17m ago' },
  { workflow: 'New Tenant Onboarding', status: 'failed', duration: '3.1s', time: '1d ago' },
  { workflow: 'Weekly Performance Report', status: 'success', duration: '12.4s', time: '2d ago' },
];

export default function Automation() {
  const [workflows, setWorkflows] = useState(WORKFLOWS);

  const toggle = (i) => setWorkflows(w => w.map((wf, idx) => idx === i ? { ...wf, status: wf.status === 'Active' ? 'Paused' : 'Active' } : wf));

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Automation" />
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">⚙ Automation</h1>
            <p className="text-slate-400 text-sm mt-1">Workflows, triggers, schedules, and run history</p>
          </div>
          <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">+ New Workflow</button>
        </div>

        <div className="p-6 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Active Workflows', value: '5', icon: '⚙', color: 'text-blue-400' },
              { label: 'Runs Today', value: '847', icon: '⚡', color: 'text-green-400' },
              { label: 'Success Rate', value: '99.1%', icon: '✅', color: 'text-teal-400' },
              { label: 'Time Saved', value: '142h', icon: '⏱', color: 'text-purple-400' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">{k.icon}</span>
                <div>
                  <div className="text-xs text-slate-500">{k.label}</div>
                  <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Workflow List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Workflows</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Name</th>
                    <th className="text-left py-2 pr-4">Trigger</th>
                    <th className="text-left py-2 pr-4">Last Run</th>
                    <th className="text-left py-2 pr-4">Total Runs</th>
                    <th className="text-left py-2 pr-4">Success</th>
                    <th className="text-left py-2 pr-4">Status</th>
                    <th className="text-left py-2">Toggle</th>
                  </tr>
                </thead>
                <tbody>
                  {workflows.map((w, i) => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                      <td className="py-3 pr-4 text-white font-medium text-xs">{w.name}</td>
                      <td className="py-3 pr-4"><span className="bg-slate-800 text-slate-400 text-xs px-2 py-0.5 rounded">{w.trigger}</span></td>
                      <td className="py-3 pr-4 text-slate-500 text-xs">{w.lastRun}</td>
                      <td className="py-3 pr-4 text-slate-300 text-xs">{w.runs.toLocaleString()}</td>
                      <td className="py-3 pr-4 text-green-400 text-xs">{w.success}</td>
                      <td className="py-3 pr-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${w.status === 'Active' ? 'bg-green-500/10 text-green-400' : 'bg-slate-700 text-slate-400'}`}>{w.status}</span>
                      </td>
                      <td className="py-3">
                        <button onClick={() => toggle(i)}
                          className={`w-9 h-5 rounded-full transition relative ${w.status === 'Active' ? 'bg-blue-600' : 'bg-slate-700'}`}>
                          <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${w.status === 'Active' ? 'left-4.5' : 'left-0.5'}`} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Run History */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Recent Run History</h2>
            <div className="space-y-2">
              {HISTORY.map((h, i) => (
                <div key={i} className="flex items-center justify-between bg-slate-800 rounded-lg px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className={`w-2 h-2 rounded-full ${h.status === 'success' ? 'bg-green-500' : 'bg-red-500'}`} />
                    <span className="text-white text-xs font-medium">{h.workflow}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span>{h.duration}</span>
                    <span>{h.time}</span>
                    <span className={h.status === 'success' ? 'text-green-400' : 'text-red-400'}>{h.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}