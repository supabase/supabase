import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import Sidebar from '@/components/Sidebar';
import ThreeDViewer from '@/components/ThreeDViewer';
import AnnotationsPanel from '@/components/AnnotationsPanel';

const NAV = [
  { category: 'OPERATIONS', items: [
    { label: 'Overview', path: '/team', icon: '◉' },
    { label: 'Event Stream', path: '/team', icon: '⚡' },
    { label: 'iTwin Explorer', path: '/itwins', icon: '◈' },
    { label: 'iModel Explorer', path: '/imodels', icon: '⬡' },
    { label: 'Integrations', path: '/integrations', icon: '🔌' },
  ]},
  { category: 'MONITORING', items: [
    { label: 'Alerts', path: '/threats', icon: '🔔' },
    { label: 'Reports', path: '/team', icon: '📊' },
  ]},
];

const IMODELS = [
  { id: '1', name: 'Civil Infrastructure Hub', iTwin: 'Smart City Alpha', size: '2.4 GB', lastSync: '2m ago', status: 'Synced', elements: 142890, type: 'Infrastructure' },
  { id: '2', name: 'Roads & Bridges Network', iTwin: 'Transport Grid', size: '1.8 GB', lastSync: '15m ago', status: 'Synced', elements: 98340, type: 'Transport' },
  { id: '3', name: 'Digital Twin Facility A', iTwin: 'Bentley Connect', size: '4.1 GB', lastSync: '1h ago', status: 'Synced', elements: 287410, type: 'Facility' },
  { id: '4', name: 'Underground Utilities Map', iTwin: 'Infrastructure Hub', size: '890 MB', lastSync: '3h ago', status: 'Outdated', elements: 56200, type: 'Utilities' },
  { id: '5', name: 'Structural Analysis Suite', iTwin: 'Model Suite B', size: '3.2 GB', lastSync: '5h ago', status: 'Syncing', elements: 193000, type: 'Structural' },
  { id: '6', name: 'Water Treatment Plant', iTwin: 'Civil Works', size: '1.1 GB', lastSync: '12h ago', status: 'Synced', elements: 74500, type: 'Facility' },
];

const STATUS_STYLE = {
  Synced: 'bg-green-500/10 text-green-400',
  Outdated: 'bg-orange-500/10 text-orange-400',
  Syncing: 'bg-blue-500/10 text-blue-400 animate-pulse',
};

export default function IModelsExplorer() {
  const { currentUser } = useAuth();
  const [selected, setSelected] = useState(IMODELS[0]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');

  const types = ['All', ...new Set(IMODELS.map(m => m.type))];
  const filtered = IMODELS.filter(m =>
    (typeFilter === 'All' || m.type === typeFilter) &&
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Operations" />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-4 border-b border-slate-800 shrink-0">
          <div>
            <h1 className="text-xl font-bold text-white">iModel Explorer</h1>
            <p className="text-slate-400 text-xs mt-0.5">Browse, inspect and visualize digital infrastructure models</p>
          </div>
          <div className="flex gap-2">
            <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">⬡ New iModel</button>
            <button className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">↻ Sync All</button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Left Panel - Model List */}
          <div className="w-80 shrink-0 border-r border-slate-800 flex flex-col overflow-hidden">
            <div className="p-3 space-y-2 border-b border-slate-800">
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Search iModels..."
                className="w-full bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
              <div className="flex gap-1 flex-wrap">
                {types.map(t => (
                  <button key={t} onClick={() => setTypeFilter(t)}
                    className={`text-xs px-2 py-0.5 rounded-full transition ${typeFilter === t ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filtered.map(m => (
                <button key={m.id} onClick={() => setSelected(m)}
                  className={`w-full text-left px-4 py-3 border-b border-slate-800/50 hover:bg-slate-800/50 transition ${selected?.id === m.id ? 'bg-slate-800 border-l-2 border-l-blue-500' : ''}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-white text-xs font-medium truncate">{m.name}</div>
                      <div className="text-slate-500 text-xs truncate">{m.iTwin}</div>
                    </div>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full shrink-0 ${STATUS_STYLE[m.status]}`}>{m.status}</span>
                  </div>
                  <div className="flex gap-3 mt-1.5 text-xs text-slate-600">
                    <span>{m.size}</span>
                    <span>{m.elements.toLocaleString()} elements</span>
                  </div>
                </button>
              ))}
            </div>
            <div className="p-3 border-t border-slate-800 text-xs text-slate-600">
              {filtered.length} of {IMODELS.length} models
            </div>
          </div>

          {/* Right Panel - 3D Viewer + Details */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {selected ? (
              <>
                {/* 3D Viewer + Annotations side by side */}
                <div className="flex h-96 border-b border-slate-800">
                  <div className="flex-1 bg-slate-900">
                    <ThreeDViewer modelName={selected.name} />
                  </div>
                  <div className="w-72 shrink-0">
                    <AnnotationsPanel model={selected} currentUser={currentUser} />
                  </div>
                </div>

                {/* Model Details */}
                <div className="flex-1 overflow-y-auto p-5 space-y-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="text-white font-bold text-lg">{selected.name}</h2>
                      <p className="text-slate-400 text-sm">iTwin: {selected.iTwin}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${STATUS_STYLE[selected.status]}`}>{selected.status}</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { label: 'Type', value: selected.type },
                      { label: 'Size', value: selected.size },
                      { label: 'Elements', value: selected.elements.toLocaleString() },
                      { label: 'Last Sync', value: selected.lastSync },
                    ].map(d => (
                      <div key={d.label} className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                        <div className="text-xs text-slate-500 mb-1">{d.label}</div>
                        <div className="text-white text-sm font-medium">{d.value}</div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                    <h3 className="text-white text-sm font-semibold mb-3">Model Actions</h3>
                    <div className="flex flex-wrap gap-2">
                      <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg transition">↻ Sync Now</button>
                      <button className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">📥 Export</button>
                      <button className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">👁 Properties</button>
                      <button className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">🔗 Share</button>
                      <button className="bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs px-3 py-1.5 rounded-lg transition">🗑 Delete</button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-slate-600">
                Select an iModel to view
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}