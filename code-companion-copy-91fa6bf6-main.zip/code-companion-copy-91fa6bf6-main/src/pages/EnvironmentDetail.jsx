import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import Sidebar from '@/components/Sidebar';
import { Globe, Rocket, CheckCircle, XCircle, Clock, AlertTriangle, ArrowLeft } from 'lucide-react';

const NAV = [
  { category: 'HIERARCHY', items: [
    { label: 'Organizations', path: '/organizations', icon: '🏢' },
    { label: 'Deployments', path: '/deployments', icon: '🚀' },
    { label: 'Health Monitor', path: '/health', icon: '💚' },
  ]},
];

const STATUS_STYLE = {
  healthy: 'bg-green-500/10 text-green-400 border-green-500/20',
  degraded: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  down: 'bg-red-500/10 text-red-400 border-red-500/20',
  deploying: 'bg-blue-500/10 text-blue-400 border-blue-500/20 animate-pulse',
  idle: 'bg-slate-700 text-slate-400 border-slate-600',
};

const DEP_STATUS_STYLE = {
  deployed: 'bg-green-500/10 text-green-400',
  failed: 'bg-red-500/10 text-red-400',
  building: 'bg-blue-500/10 text-blue-400',
  queued: 'bg-slate-700 text-slate-400',
  rolled_back: 'bg-orange-500/10 text-orange-400',
};

const DEP_ICON = { deployed: CheckCircle, failed: XCircle, building: Clock, queued: Clock, rolled_back: AlertTriangle };

export default function EnvironmentDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const envId = urlParams.get('id');

  const [env, setEnv] = useState(null);
  const [deployments, setDeployments] = useState([]);
  const [integrations, setIntegrations] = useState([]);
  const [license, setLicense] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!envId) { setLoading(false); return; }

    Promise.all([
      base44.entities.Environment.filter({ id: envId }),
      base44.entities.Deployment.filter({ environment_id: envId }, '-created_date', 50),
      base44.entities.IntegrationConnection.list('-created_date', 20),
    ]).then(([envData, depsData, intgData]) => {
      setEnv(envData[0] || null);
      setDeployments(depsData);
      setIntegrations(intgData);
      setLoading(false);
    });

    const unsub = base44.entities.Deployment.subscribe(event => {
      if (event.data?.environment_id !== envId) return;
      if (event.type === 'create') setDeployments(p => [event.data, ...p]);
      else if (event.type === 'update') setDeployments(p => p.map(d => d.id === event.id ? event.data : d));
    });
    return unsub;
  }, [envId]);

  useEffect(() => {
    if (!env?.organization_id) return;
    base44.entities.License.filter({ organization_id: env.organization_id }, '-created_date', 1)
      .then(data => setLicense(data[0] || null));
  }, [env]);

  if (loading) return (
    <div className="flex min-h-screen bg-slate-950 items-center justify-center">
      <div className="w-8 h-8 border-4 border-slate-700 border-t-blue-500 rounded-full animate-spin" />
    </div>
  );

  if (!env && !loading) return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Developer" />
      <div className="flex-1 flex items-center justify-center flex-col gap-4">
        <Globe className="w-12 h-12 text-slate-700" />
        <div className="text-slate-400">Environment not found. <Link to="/organizations" className="text-blue-400">Browse orgs →</Link></div>
      </div>
    </div>
  );

  const lastDeploy = deployments[0];
  const statusCfg = STATUS_STYLE[env?.status] || STATUS_STYLE.idle;

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Developer" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
          <Link to="/organizations" className="text-slate-500 hover:text-white transition">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-teal-400" />
              {env?.name}
              <span className={`text-xs px-2 py-0.5 rounded border ml-1 ${statusCfg}`}>{env?.status}</span>
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">
              {env?.type} · {env?.region || 'No region'} · {env?.runtime || 'docker'} · Project: {env?.project_name || env?.project_id}
            </p>
          </div>
          {env?.url && (
            <a href={env.url} target="_blank" rel="noreferrer"
              className="bg-teal-600 hover:bg-teal-700 text-white text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1">
              <Globe className="w-3.5 h-3.5" /> Open
            </a>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Summary cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Deployments', value: deployments.length, color: 'text-white' },
              { label: 'Successful', value: deployments.filter(d => d.status === 'deployed').length, color: 'text-green-400' },
              { label: 'Failed', value: deployments.filter(d => d.status === 'failed').length, color: 'text-red-400' },
              { label: 'Last Deploy', value: lastDeploy ? new Date(lastDeploy.created_date).toLocaleDateString() : '—', color: 'text-slate-300' },
            ].map(k => (
              <div key={k.label} className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
                <div className="text-xs text-slate-500">{k.label}</div>
                <div className={`text-xl font-bold ${k.color}`}>{k.value}</div>
              </div>
            ))}
          </div>

          {/* License quota */}
          {license && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
              <h2 className="text-white font-semibold mb-3 text-sm flex items-center gap-2">🔑 License Quota — {license.plan}</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-xs mb-1 text-slate-400">
                    <span>Deployments Used</span>
                    <span>{license.deployments_used || 0} / {license.deployment_quota || 100}</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${Math.min(100, ((license.deployments_used || 0) / (license.deployment_quota || 100)) * 100)}%` }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1 text-slate-400">
                    <span>Seats Used</span>
                    <span>{license.seats_used || 0} / {license.seat_limit || 5}</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: `${Math.min(100, ((license.seats_used || 0) / (license.seat_limit || 5)) * 100)}%` }} />
                  </div>
                </div>
              </div>
              <div className={`mt-2 text-xs ${license.status === 'active' ? 'text-green-400' : 'text-red-400'}`}>
                License: {license.status} · Expires: {license.expires_at ? new Date(license.expires_at).toLocaleDateString() : 'Never'}
              </div>
            </div>
          )}

          {/* Deployments */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
              <h2 className="text-white font-semibold text-sm flex items-center gap-2"><Rocket className="w-4 h-4 text-green-400" /> Deployments</h2>
              <Link to="/deployments" className="text-blue-400 text-xs hover:text-blue-300">View all →</Link>
            </div>
            {deployments.length === 0 ? (
              <div className="text-center text-slate-600 py-10 text-sm">No deployments yet for this environment.</div>
            ) : (
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left px-5 py-3">App</th>
                    <th className="text-left px-5 py-3">Version</th>
                    <th className="text-left px-5 py-3">Status</th>
                    <th className="text-left px-5 py-3">By</th>
                    <th className="text-left px-5 py-3">When</th>
                  </tr>
                </thead>
                <tbody>
                  {deployments.slice(0, 20).map(dep => {
                    const Icon = DEP_ICON[dep.status] || Clock;
                    return (
                      <tr key={dep.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="px-5 py-3 text-white font-medium">{dep.app_name}</td>
                        <td className="px-5 py-3 text-slate-400">{dep.version}</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-0.5 rounded flex items-center gap-1 w-fit ${DEP_STATUS_STYLE[dep.status] || 'bg-slate-700 text-slate-400'}`}>
                            <Icon className="w-3 h-3" /> {dep.status}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-slate-500">{dep.triggered_by}</td>
                        <td className="px-5 py-3 text-slate-500">{new Date(dep.created_date).toLocaleString()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>

          {/* Integration connections */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h2 className="text-white font-semibold mb-3 text-sm">Integration Connections</h2>
            {integrations.length === 0 ? (
              <div className="text-slate-600 text-sm">No integrations connected. <Link to="/integrations" className="text-blue-400">Configure →</Link></div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {integrations.map(intg => (
                  <span key={intg.id} className={`text-xs px-3 py-1.5 rounded-lg border ${intg.status === 'connected' ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>
                    {intg.integration_name} · {intg.status}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Env config */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h2 className="text-white font-semibold mb-3 text-sm">Configuration</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                ['Runtime', env?.runtime || '—'],
                ['Region', env?.region || '—'],
                ['Type', env?.type || '—'],
                ['Last Deployed', env?.last_deployed_at ? new Date(env.last_deployed_at).toLocaleString() : '—'],
              ].map(([k, v]) => (
                <div key={k} className="bg-slate-800 rounded-lg px-3 py-2">
                  <div className="text-xs text-slate-500">{k}</div>
                  <div className="text-white text-xs font-medium">{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}