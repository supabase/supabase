import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Sidebar from '@/components/Sidebar';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const NAV = [
  { category: 'OPERATIONS', items: [
    { label: 'Overview', path: '/team', icon: '◉' },
    { label: 'iModel Explorer', path: '/imodels', icon: '⬡' },
    { label: 'Integrations', path: '/integrations', icon: '🔌' },
    { label: 'Deployments', path: '/deployments', icon: '🚀' },
  ]},
  { category: 'MONITORING', items: [
    { label: 'Alerts', path: '/alerts', icon: '🔔' },
    { label: 'Health', path: '/health', icon: '💚' },
  ]},
];

const SEVERITY_COLORS = { info: '#3b82f6', success: '#22c55e', warning: '#f97316', error: '#ef4444' };

const MOCK_EVENTS = [
  { type: 'iModels.iModelCreated.v1', category: 'iModels', iTwin: 'Bentley Connect', severity: 'success', received: '2m ago' },
  { type: 'synchronization.runCompleted.v1', category: 'Sync', iTwin: 'Digital Twin Alpha', severity: 'info', received: '5m ago' },
  { type: 'iTwins.iTwinUpdated.v1', category: 'iTwins', iTwin: 'Infrastructure Hub', severity: 'info', received: '8m ago' },
  { type: 'accessControl.memberAdded.v1', category: 'Access', iTwin: 'Bentley Connect', severity: 'success', received: '12m ago' },
  { type: 'synchronization.runFailed.v1', category: 'Sync', iTwin: 'Model Suite B', severity: 'error', received: '18m ago' },
  { type: 'issues.issueCreated.v1', category: 'Issues', iTwin: 'Civil Works', severity: 'warning', received: '22m ago' },
  { type: 'iModels.iModelUpdated.v1', category: 'iModels', iTwin: 'Roads & Bridges', severity: 'info', received: '31m ago' },
  { type: 'iTwins.iTwinCreated.v1', category: 'iTwins', iTwin: 'Smart City', severity: 'success', received: '45m ago' },
];

const TREND_DATA = [
  { time: '00:00', events: 12 }, { time: '03:00', events: 8 }, { time: '06:00', events: 15 },
  { time: '09:00', events: 42 }, { time: '12:00', events: 67 }, { time: '15:00', events: 58 },
  { time: '18:00', events: 73 }, { time: '21:00', events: 34 }, { time: 'Now', events: 29 },
];

const CATEGORY_DATA = [
  { name: 'iModels', value: 38, color: '#3b82f6' },
  { name: 'iTwins', value: 27, color: '#a855f7' },
  { name: 'Sync', value: 21, color: '#14b8a6' },
  { name: 'Issues', value: 9, color: '#f97316' },
  { name: 'Access', value: 5, color: '#22c55e' },
];

export default function TeamDashboard() {
  const { currentUser } = useAuth();
  const [activeRange, setActiveRange] = useState('24h');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showTestModal, setShowTestModal] = useState(false);
  const [tick, setTick] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [integrations, setIntegrations] = useState([]);
  const [testEventType, setTestEventType] = useState('iModels.iModelCreated.v1');
  const [testITwin, setTestITwin] = useState('');
  const [testSending, setTestSending] = useState(false);
  const [testSent, setTestSent] = useState(false);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(() => setTick(t => t + 1), 15000);
    return () => clearInterval(id);
  }, [autoRefresh]);

  useEffect(() => {
    Promise.all([
      base44.entities.Alert.list('-created_date', 20),
      base44.entities.Deployment.list('-created_date', 50),
      base44.entities.IntegrationConnection.filter({ status: 'connected' }, '-created_date', 20),
    ]).then(([aData, dData, iData]) => {
      setAlerts(aData);
      setDeployments(dData);
      setIntegrations(iData);
    });
    const unsubA = base44.entities.Alert.subscribe(e => {
      if (e.type === 'create') setAlerts(p => [e.data, ...p]);
      else if (e.type === 'update') setAlerts(p => p.map(a => a.id === e.id ? e.data : a));
    });
    const unsubD = base44.entities.Deployment.subscribe(e => {
      if (e.type === 'create') setDeployments(p => [e.data, ...p]);
      else if (e.type === 'update') setDeployments(p => p.map(d => d.id === e.id ? e.data : d));
    });
    return () => { unsubA(); unsubD(); };
  }, [tick]);

  const sendTestEvent = async () => {
    setTestSending(true);
    await base44.entities.Alert.create({
      title: `Test: ${testEventType}`,
      description: `Simulated test event for iTwin: ${testITwin || 'Unknown'}`,
      severity: 'Info',
      status: 'Active',
      source: testITwin || 'Test Harness',
    });
    setTestSent(true);
    setTestSending(false);
    setTimeout(() => { setTestSent(false); setShowTestModal(false); }, 1500);
  };

  const kpis = [
    { label: 'Active Alerts', value: alerts.filter(a => a.status === 'Active').length, icon: '◉', color: 'text-red-400 bg-red-500/10' },
    { label: 'Total Alerts', value: alerts.length, icon: '◈', color: 'text-blue-400 bg-blue-500/10' },
    { label: 'Deployments', value: deployments.length, icon: '🚀', color: 'text-teal-400 bg-teal-500/10' },
    { label: 'Deployed', value: deployments.filter(d => d.status === 'deployed').length, icon: '✅', color: 'text-green-400 bg-green-500/10' },
    { label: 'Integrations', value: integrations.length, icon: '🔌', color: 'text-purple-400 bg-purple-500/10' },
  ];

  const quickActions = [
    { icon: '🔔', label: 'Alerts', desc: 'Manage active incidents', path: '/alerts' },
    { icon: '⬡', label: 'iModel Explorer', desc: 'Browse digital models', path: '/imodels' },
    { icon: '🚀', label: 'Deployments', desc: 'Track all deployments', path: '/deployments' },
    { icon: '🔌', label: 'Integrations', desc: 'Connect dev tools', path: '/integrations' },
    { icon: '💚', label: 'Health Monitor', desc: 'System health & uptime', path: '/health' },
    { icon: '⚙', label: 'Admin Settings', desc: 'Configure platform', path: '/admin' },
  ];

  return (
    <div className="flex min-h-screen bg-slate-950">
      <Sidebar navItems={NAV} role="Operations" />
      <div className="flex-1 overflow-auto">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-6 py-5 border-b border-slate-800">
          <div>
            <h1 className="text-2xl font-bold text-white">Operations Overview</h1>
            <p className="text-slate-400 text-sm flex items-center gap-2 mt-1">
              <span className="w-2 h-2 rounded-full bg-green-500 inline-block animate-pulse" />
              Live Bentley iTwin event intelligence
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex bg-slate-800 rounded-lg p-1 gap-1">
              {['1H','6H','24H','7D','30D'].map(r => (
                <button key={r} onClick={() => setActiveRange(r)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all ${activeRange === r ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                  {r}
                </button>
              ))}
            </div>
            <button onClick={() => setShowTestModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 transition">
              ⚡ Test Event
            </button>
            <button onClick={() => setTick(t => t + 1)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition">
              ↻ Refresh
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {kpis.map((kpi) => (
              <div key={kpi.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl ${kpi.color}`}>
                  {kpi.icon}
                </div>
                <div>
                  <div className="text-xs text-slate-500">{kpi.label}</div>
                  <div className="text-2xl font-bold text-white">{kpi.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Trend Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-white font-semibold">Event Volume Trend</h2>
              <span className="text-slate-500 text-xs">Last {activeRange}</span>
            </div>
            <ResponsiveContainer width="100%" height={170}>
              <AreaChart data={TREND_DATA}>
                <defs>
                  <linearGradient id="eventGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }} labelStyle={{ color: '#94a3b8' }} itemStyle={{ color: '#60a5fa' }} />
                <Area type="monotone" dataKey="events" stroke="#3b82f6" fill="url(#eventGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* System Health */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">System Health</h2>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                <span className="text-green-400 font-medium">All Systems Operational</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: 'Webhook Receiver', status: 'Operational', ok: true },
                  { label: 'Event Processing', status: 'Operational', ok: true },
                  { label: 'Alert Routing', status: 'Operational', ok: true },
                  { label: 'iTwin API', status: 'Operational', ok: true },
                  { label: 'Database', status: 'Operational', ok: true },
                ].map(s => (
                  <div key={s.label} className="flex items-center justify-between py-1 border-b border-slate-800">
                    <span className="text-slate-400 text-sm">{s.label}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${s.ok ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                      {s.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Event Categories Donut */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Event Categories</h2>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width={140} height={140}>
                  <PieChart>
                    <Pie data={CATEGORY_DATA} cx={65} cy={65} innerRadius={45} outerRadius={65} dataKey="value" strokeWidth={0}>
                      {CATEGORY_DATA.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-2 flex-1">
                  {CATEGORY_DATA.map(c => (
                    <div key={c.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                        <span className="text-slate-400 text-xs">{c.name}</span>
                      </div>
                      <span className="text-white text-xs font-semibold">{c.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top Event Types */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-white font-semibold mb-4">Top Event Types</h2>
              <div className="space-y-3">
                {[
                  { type: 'iModelCreated', count: 412, pct: 85 },
                  { type: 'runCompleted', count: 318, pct: 65 },
                  { type: 'iTwinUpdated', count: 267, pct: 55 },
                  { type: 'memberAdded', count: 189, pct: 39 },
                  { type: 'issueCreated', count: 134, pct: 27 },
                ].map(t => (
                  <div key={t.type}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">{t.type}</span>
                      <span className="text-white font-medium">{t.count}</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${t.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Event Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-white font-semibold">Recent Event Feed</h2>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                  <input type="checkbox" checked={autoRefresh} onChange={e => setAutoRefresh(e.target.checked)} className="accent-blue-500" />
                  Auto-refresh
                </label>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-500 uppercase border-b border-slate-800">
                    <th className="text-left py-2 pr-4">Event Type</th>
                    <th className="text-left py-2 pr-4">Category</th>
                    <th className="text-left py-2 pr-4">iTwin</th>
                    <th className="text-left py-2 pr-4">Severity</th>
                    <th className="text-left py-2">Received</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.length === 0 && (
              <tr><td colSpan={5} className="py-6 text-center text-slate-600 text-sm">No events yet. Create a test event or wait for real alerts.</td></tr>
            )}
            {alerts.slice(0, 10).map((ev, i) => (
              <tr key={ev.id || i} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition">
                <td className="py-2.5 pr-4 text-slate-300 font-mono text-xs">{ev.title}</td>
                <td className="py-2.5 pr-4">
                  <span className="bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-xs">{ev.source}</span>
                </td>
                <td className="py-2.5 pr-4 text-slate-400 text-xs">{ev.description?.slice(0, 40)}</td>
                <td className="py-2.5 pr-4">
                  <span className="text-xs capitalize" style={{ color: SEVERITY_COLORS[ev.severity?.toLowerCase()] || '#94a3b8' }}>{ev.severity}</span>
                </td>
                <td className="py-2.5 text-slate-500 text-xs">{new Date(ev.created_date).toLocaleTimeString()}</td>
              </tr>
            ))}
            </tbody>
              </table>
            </div>
            <p className="text-xs text-slate-600 mt-3">Auto-refreshes every 15s</p>
          </div>

          {/* Quick Actions */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-white font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {quickActions.map((a) => (
                <Link key={a.label} to={a.path}
                  className="bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl p-4 text-center transition group">
                  <div className="text-2xl mb-2">{a.icon}</div>
                  <div className="text-white text-sm font-medium group-hover:text-blue-400 transition">{a.label}</div>
                  <div className="text-slate-500 text-xs mt-1">{a.desc}</div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Test Event Modal */}
      {showTestModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-slate-800">
              <h3 className="text-white font-bold">⚡ Send Test Event</h3>
              <button onClick={() => setShowTestModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Event Type</label>
                <select value={testEventType} onChange={e => setTestEventType(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm">
                  <option>iModels.iModelCreated.v1</option>
                  <option>iModels.iModelUpdated.v1</option>
                  <option>iTwins.iTwinCreated.v1</option>
                  <option>synchronization.runCompleted.v1</option>
                  <option>issues.issueCreated.v1</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">iTwin Name</label>
                <input value={testITwin} onChange={e => setTestITwin(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm" placeholder="e.g. Bentley Connect" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">Quantity</label>
                <select className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm">
                  <option>1 event</option>
                  <option>5 events</option>
                  <option>10 events</option>
                  <option>25 events</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-slate-800">
              <button onClick={() => setShowTestModal(false)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg py-2 text-sm transition">Cancel</button>
              <button onClick={sendTestEvent} disabled={testSending}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg py-2 text-sm transition">
                {testSent ? '✓ Sent!' : testSending ? 'Sending...' : 'Send Event'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}