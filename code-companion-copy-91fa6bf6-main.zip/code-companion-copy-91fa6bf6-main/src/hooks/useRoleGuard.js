import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';

/**
 * Roles hierarchy: admin > user
 * Use this hook at the top of any page that requires a minimum role.
 *
 * Usage:
 *   useRoleGuard('admin')          — only admins
 *   useRoleGuard('user')           — any logged-in user (default)
 *   useRoleGuard('admin', '/team') — redirect to /team instead of /
 */
export function useRoleGuard(requiredRole = 'user', redirectTo = '/') {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentUser) return;
    if (requiredRole === 'admin' && currentUser.role !== 'admin') {
      navigate(redirectTo, { replace: true });
    }
  }, [currentUser, requiredRole, redirectTo, navigate]);

  const isAdmin = currentUser?.role === 'admin';
  const canAccess = (role) => {
    if (role === 'admin') return isAdmin;
    return true; // 'user' — any authenticated user
  };

  return { isAdmin, canAccess, currentUser };
}

export default useRoleGuard;