import { Button } from '@/components/ui/button';
import { ArrowLeft, CheckCircle, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function RecommendationResults({ recommendations, analysis, formData, onBack }) {
  const navigate = useNavigate();
  const getMatchColor = (score) => {
    const percent = parseInt(score);
    if (percent >= 90) return 'text-green-500';
    if (percent >= 75) return 'text-blue-500';
    return 'text-yellow-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-blue-400 hover:text-blue-300 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Adjust Preferences
          </button>
          <h1 className="text-4xl font-bold text-white mb-3">Your Personalized Recommendations</h1>
          <p className="text-slate-400">Based on your preferences for ${formData.budget_min}K-${formData.budget_max}K</p>
        </div>

        {/* Overall Analysis */}
        {analysis && (
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 mb-8">
            <h2 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-500" />
              AI Analysis
            </h2>
            <p className="text-slate-300 leading-relaxed">{analysis}</p>
          </div>
        )}

        {/* Recommendations */}
        <div className="space-y-6 mb-12">
          {recommendations.map((rec, idx) => (
            <div
              key={idx}
              className="bg-slate-800 border border-slate-700 rounded-lg p-8 hover:border-blue-500/50 transition"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="text-sm font-semibold bg-blue-600 text-white px-3 py-1 rounded-full">
                      #{idx + 1}
                    </div>
                    <h3 className="text-2xl font-bold text-white">{rec.model_name}</h3>
                  </div>
                  <p className="text-slate-400">Estimated Price: {rec.price_estimate}</p>
                </div>
                <div className={`text-right ${getMatchColor(rec.match_score)}`}>
                  <div className="text-3xl font-bold">{rec.match_score}</div>
                  <div className="text-xs text-slate-400">Match Score</div>
                </div>
              </div>

              <p className="text-slate-300 mb-6 text-lg">{rec.reason}</p>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">Key Advantages</h4>
                <div className="grid md:grid-cols-2 gap-3">
                  {rec.advantages.map((advantage, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-slate-300">{advantage}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={() => navigate('/virtual-test-drive', { state: { modelName: rec.model_name } })}
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  Virtual Test Drive
                </Button>
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Learn More
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Compare & Test Drive Section */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">Compare & Experience</h2>
          <p className="text-slate-300 mb-6">Select multiple models to compare specs side-by-side or take virtual test drives</p>
          <Button
            onClick={() => navigate('/compare-models', { state: { recommendations } })}
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
          >
            Compare Up to 3 Models
          </Button>
        </div>

        {/* Call to Action */}
        <div className="bg-blue-600/20 border border-blue-500/50 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">Ready to Explore These Options?</h2>
          <p className="text-slate-300 mb-6">Contact our sales team to schedule a test drive or get more information about any of these models.</p>
          <div className="flex gap-4 justify-center">
            <Button className="bg-blue-600 hover:bg-blue-700">Contact Sales Team</Button>
            <Button
              onClick={() => navigate('/')}
              variant="outline"
              className="border-blue-400 text-blue-400 hover:bg-blue-400/10"
            >
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}