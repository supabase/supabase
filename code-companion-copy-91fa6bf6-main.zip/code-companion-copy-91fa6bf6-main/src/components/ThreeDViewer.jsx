import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function ThreeDViewer({ modelName = 'iModel' }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    const width = mount.clientWidth;
    const height = mount.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    scene.fog = new THREE.Fog(0x0f172a, 10, 50);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(4, 3, 6);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    mount.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x334155, 1.5);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0x60a5fa, 2);
    dirLight.position.set(5, 10, 5);
    dirLight.castShadow = true;
    scene.add(dirLight);
    const pointLight = new THREE.PointLight(0x3b82f6, 1, 20);
    pointLight.position.set(-3, 3, -3);
    scene.add(pointLight);

    // Grid
    const grid = new THREE.GridHelper(20, 20, 0x1e293b, 0x1e293b);
    scene.add(grid);

    // Building-like structure
    const group = new THREE.Group();
    const matBlue = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, metalness: 0.5, roughness: 0.3 });
    const matTeal = new THREE.MeshStandardMaterial({ color: 0x0d9488, metalness: 0.4, roughness: 0.4 });
    const matGray = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.6, roughness: 0.2 });

    // Main body
    const body = new THREE.Mesh(new THREE.BoxGeometry(2, 3, 2), matBlue);
    body.position.y = 1.5;
    body.castShadow = true;
    group.add(body);

    // Tower
    const tower = new THREE.Mesh(new THREE.BoxGeometry(0.8, 2, 0.8), matGray);
    tower.position.set(0, 4, 0);
    tower.castShadow = true;
    group.add(tower);

    // Roof accent
    const roof = new THREE.Mesh(new THREE.CylinderGeometry(0, 0.7, 1, 4), matTeal);
    roof.position.set(0, 5.5, 0);
    group.add(roof);

    // Side wings
    [-1.8, 1.8].forEach(x => {
      const wing = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.5, 1.5), matGray);
      wing.position.set(x, 0.75, 0);
      wing.castShadow = true;
      group.add(wing);
    });

    // Floating nodes
    for (let i = 0; i < 6; i++) {
      const node = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0x60a5fa, emissive: 0x3b82f6, emissiveIntensity: 1 })
      );
      node.position.set(
        (Math.random() - 0.5) * 5,
        Math.random() * 4 + 1,
        (Math.random() - 0.5) * 5
      );
      group.add(node);
    }

    scene.add(group);

    // Mouse orbit
    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };
    let rotY = 0, rotX = 0;

    const onMouseDown = e => { isDragging = true; prevMouse = { x: e.clientX, y: e.clientY }; };
    const onMouseUp = () => { isDragging = false; };
    const onMouseMove = e => {
      if (!isDragging) return;
      rotY += (e.clientX - prevMouse.x) * 0.005;
      rotX += (e.clientY - prevMouse.y) * 0.005;
      rotX = Math.max(-0.8, Math.min(0.8, rotX));
      prevMouse = { x: e.clientX, y: e.clientY };
    };
    const onWheel = e => { camera.position.multiplyScalar(1 + e.deltaY * 0.001); };

    mount.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    mount.addEventListener('wheel', onWheel);

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      group.rotation.y = rotY + Date.now() * 0.0003;
      group.rotation.x = rotX;
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      const w = mount.clientWidth, h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      mount.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      mount.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', handleResize);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full h-full">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      <div className="absolute top-3 left-3 bg-slate-900/80 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-400">
        🖱 Drag to rotate · Scroll to zoom
      </div>
      <div className="absolute bottom-3 left-3 bg-slate-900/80 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-blue-400 font-mono">
        {modelName}
      </div>
    </div>
  );
}