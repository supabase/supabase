import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';

export default function Sidebar({ navItems = [], role = 'User' }) {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className={`${collapsed ? 'w-16' : 'w-60'} shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col transition-all duration-200 min-h-screen`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-slate-800">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-sm">B</div>
            <div>
              <div className="text-white text-sm font-bold leading-tight">Bentley</div>
              <div className="text-slate-500 text-xs">{role}</div>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-sm mx-auto">B</div>
        )}
        {!collapsed && (
          <button onClick={() => setCollapsed(true)} className="text-slate-500 hover:text-white text-xs">◀</button>
        )}
      </div>

      {collapsed && (
        <button onClick={() => setCollapsed(false)} className="text-slate-500 hover:text-white text-xs py-2 text-center">▶</button>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-4">
        {navItems.map(group => (
          <div key={group.category}>
            {!collapsed && (
              <div className="text-xs text-slate-600 font-semibold px-2 mb-2 tracking-widest">{group.category}</div>
            )}
            <div className="space-y-0.5">
              {group.items.map(item => {
                const isActive = location.pathname === item.path;
                return (
                  <Link key={item.label} to={item.path}
                    className={`flex items-center gap-3 px-2 py-2 rounded-lg text-sm transition-all ${isActive ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                    title={collapsed ? item.label : undefined}>
                    <span className="text-base shrink-0">{item.icon}</span>
                    {!collapsed && <span>{item.label}</span>}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-slate-800 p-3">
        {!collapsed ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white">U</div>
              <div className="text-xs text-slate-400">{role}</div>
            </div>
            <button onClick={() => base44.auth.logout()} className="text-xs text-slate-500 hover:text-red-400 transition">Logout</button>
          </div>
        ) : (
          <button onClick={() => base44.auth.logout()} className="w-full text-center text-slate-500 hover:text-red-400 text-xs transition">↩</button>
        )}
      </div>
    </div>
  );
}