import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];
const MARKER_OPTIONS = ['Section A', 'Section B', 'Node 4', 'Level 2', 'Foundation', 'Roof', 'Custom'];

export default function AnnotationsPanel({ model, currentUser }) {
  const [annotations, setAnnotations] = useState([]);
  const [text, setText] = useState('');
  const [marker, setMarker] = useState('Section A');
  const [color, setColor] = useState(COLORS[0]);
  const [loading, setLoading] = useState(false);
  const [activeUsers] = useState(['You', 'M. Torres', 'A. Chen']);

  useEffect(() => {
    if (!model) return;
    base44.entities.Annotation.filter({ model_id: model.id }, '-created_date', 50)
      .then(setAnnotations);

    const unsub = base44.entities.Annotation.subscribe((event) => {
      if (event.data?.model_id !== model.id) return;
      if (event.type === 'create') setAnnotations(prev => [event.data, ...prev]);
      else if (event.type === 'delete') setAnnotations(prev => prev.filter(a => a.id !== event.id));
    });
    return unsub;
  }, [model?.id]);

  const submit = async () => {
    if (!text.trim()) return;
    setLoading(true);
    await base44.entities.Annotation.create({
      model_id: model.id,
      model_name: model.name,
      text: text.trim(),
      marker_label: marker,
      color,
      author_name: currentUser?.full_name || currentUser?.email || 'Anonymous',
    });
    setText('');
    setLoading(false);
  };

  const remove = async (id) => {
    await base44.entities.Annotation.delete(id);
    setAnnotations(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-800">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-white text-sm font-semibold">💬 Annotations</h3>
          <span className="text-xs text-green-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse inline-block" />
            Live
          </span>
        </div>
        {/* Active users */}
        <div className="flex items-center gap-1.5">
          {activeUsers.map((u, i) => (
            <div key={i} title={u}
              className="w-6 h-6 rounded-full bg-blue-600 border-2 border-slate-900 flex items-center justify-center text-white text-xs font-bold"
              style={{ marginLeft: i > 0 ? '-6px' : 0 }}>
              {u[0]}
            </div>
          ))}
          <span className="text-xs text-slate-500 ml-2">{activeUsers.length} viewing</span>
        </div>
      </div>

      {/* Add annotation */}
      <div className="p-3 border-b border-slate-800 space-y-2">
        <select value={marker} onChange={e => setMarker(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-blue-500">
          {MARKER_OPTIONS.map(o => <option key={o}>{o}</option>)}
        </select>
        <textarea value={text} onChange={e => setText(e.target.value)}
          placeholder="Add annotation..."
          rows={2}
          className="w-full bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500 resize-none" />
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5">
            {COLORS.map(c => (
              <button key={c} onClick={() => setColor(c)}
                className={`w-4 h-4 rounded-full border-2 transition ${color === c ? 'border-white' : 'border-transparent'}`}
                style={{ backgroundColor: c }} />
            ))}
          </div>
          <button onClick={submit} disabled={loading || !text.trim()}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs px-3 py-1.5 rounded-lg transition">
            {loading ? '...' : 'Post'}
          </button>
        </div>
      </div>

      {/* Annotation list */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800">
        {annotations.length === 0 && (
          <div className="text-center text-slate-600 text-xs py-8">No annotations yet</div>
        )}
        {annotations.map(a => (
          <div key={a.id} className="px-4 py-3 hover:bg-slate-800/40 group">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: a.color || COLORS[0] }} />
                <span className="text-xs font-mono text-slate-400 shrink-0">{a.marker_label || '—'}</span>
              </div>
              <button onClick={() => remove(a.id)}
                className="text-slate-700 hover:text-red-400 text-xs opacity-0 group-hover:opacity-100 transition shrink-0">✕</button>
            </div>
            <p className="text-white text-xs mt-1 leading-relaxed">{a.text}</p>
            <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-600">
              <span>{a.author_name}</span>
              <span>·</span>
              <span>{new Date(a.created_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}